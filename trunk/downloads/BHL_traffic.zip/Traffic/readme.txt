############################################################################################################
#NOTE: The rule requires cells to 'wait' to move every other step and keep their moves synchronized.       #
#As a result instead of 2 states, there are 4: two states for moving cares and two states for waiting ones.#
#For a pattern to be valid it MUST consist ENTIRELY of states 0, 1, and 2 or ENTIRELY of states 0, 3 and 4.#
############################################################################################################

The Biham-Middleton-Levine traffic model is as follows:

1. The universe is typically a finite torus populated with road and cars. Road is state 0.
Cars move either right or down.

2. The cars take turns moving. During a turn, all cars of the corresponding type will attempt to move their respective direction: if there is a car blocking their path, they will not move. If there is not, they will.



Rule table written by Christian Manahl(twinb7)