# Generator for Turmite rules
#
# Following work of Ed Pegg Jr.
# specifically the Mathematica notebook linked-to from here:
# http://www.mathpuzzle.com/26Mar03.html
#
# contact: tim.hutton@gmail.com

# TODO: add this/some explanation to the generated tree file

import golly
import random
import time
import string

dirs=['N','E','S','W']
opposite_dirs=[2,3,0,1] # index of opposite direction
turn={ # index of new direction 
1:[0,1,2,3], # no turn
2:[1,2,3,0], # right
4:[2,3,0,1], # u-turn
8:[3,0,1,2], # left
}

prefix = 'Turmite' 

# N.B. Translating from Langtons-Ant-nColor to Turmite is easy:
# e.g. LLRR is (1 state, 4 color) {{{1,8,0},{2,8,0},{3,2,0},{0,2,0}}}
# but translating the other way is only possible if the Turmite has 
# exactly 1 state and only moves left or right

EdPeggJrTurmiteLibrary = [
# source: http://demonstrations.wolfram.com/Turmites/
# Translated into his later notation: 1=noturn, 2=right, 4=u-turn, 8=left
# (old notation was: 0=noturn,1=right,-1=left)
# (all these are 2-color patterns)
"{{{1, 2, 0}, {0, 8, 0}}}",  # 1: Langton's ant
"{{{1, 2, 0}, {0, 1, 0}}}",  # 2: binary counter
"{{{0, 8, 1}, {1, 2, 1}}, {{1, 1, 0}, {1, 1, 1}}}", # 3: (filled triangle)
"{{{0, 1, 1}, {0, 8, 1}}, {{1, 2, 0}, {0, 1, 1}}}", # 4: spiral in a box
"{{{0, 2, 1}, {0, 8, 0}}, {{1, 8, 1}, {0, 2, 0}}}", # 5: stripe-filled spiral
"{{{0, 2, 1}, {0, 8, 0}}, {{1, 8, 1}, {1, 1, 0}}}", # 6: stepped pyramid
"{{{0, 2, 1}, {0, 1, 1}}, {{1, 2, 1}, {1, 8, 0}}}", # 7: contoured island
"{{{0, 2, 1}, {0, 2, 1}}, {{1, 1, 0}, {0, 2, 1}}}", # 8: woven placemat
"{{{0, 2, 1}, {1, 2, 1}}, {{1, 8, 1}, {1, 8, 0}}}", # 9: snowflake-ish
"{{{1, 8, 0}, {0, 1, 1}}, {{0, 8, 0}, {0, 8, 1}}}", # 10: slow city builder
"{{{1, 8, 0}, {1, 2, 1}}, {{0, 2, 0}, {0, 8, 1}}}", # 11: framed computer art
"{{{1, 8, 0}, {1, 2, 1}}, {{0, 2, 1}, {1, 8, 0}}}", # 12: balloon bursting (makes a spreading highway)
"{{{1, 8, 1}, {0, 8, 0}}, {{1, 1, 0}, {0, 1, 0}}}", # 13: makes a horizontal highway
"{{{1, 8, 1}, {0, 8, 0}}, {{1, 2, 1}, {1, 2, 0}}}", # 14: makes a 45 degree highway
"{{{1, 8, 1}, {0, 8, 1}}, {{1, 2, 1}, {0, 8, 0}}}", # 15: makes a 45 degree highway
"{{{1, 8, 1}, {0, 1, 0}}, {{1, 1, 0}, {1, 2, 0}}}", # 16: spiral in a filled box
"{{{1, 8, 1}, {0, 2, 0}}, {{0, 8, 0}, {0, 8, 0}}}", # 17: glaciers
"{{{1, 8, 1}, {1, 8, 1}}, {{1, 2, 1}, {0, 1, 0}}}", # 18: golden rectangle!
"{{{1, 8, 1}, {1, 2, 0}}, {{0, 8, 0}, {0, 8, 0}}}", # 19: fizzy spill
"{{{1, 8, 1}, {1, 2, 1}}, {{1, 1, 0}, {0, 1, 1}}}", # 20: nested cabinets
"{{{1, 1, 1}, {0, 8, 1}}, {{1, 2, 0}, {1, 1, 1}}}", # 21: (cross)
"{{{1, 1, 1}, {0, 1, 0}}, {{0, 2, 0}, {1, 8, 0}}}", # 22: saw-tipped growth
"{{{1, 1, 1}, {0, 1, 1}}, {{1, 2, 1}, {0, 1, 0}}}", # 23: curves in blocks growth
"{{{1, 1, 1}, {0, 2, 0}}, {{0, 8, 0}, {0, 8, 0}}}", # 24: textured growth
"{{{1, 1, 1}, {0, 2, 1}}, {{1, 8, 0}, {1, 2, 0}}}", # 25: (diamond growth)
"{{{1, 1, 1}, {1, 8, 0}}, {{1, 2, 1}, {0, 1, 0}}}", # 26: coiled rope
"{{{1, 2, 0}, {0, 8, 1}}, {{1, 8, 0}, {0, 1, 1}}}", # 27: (growth)
"{{{1, 2, 0}, {0, 8, 1}}, {{1, 8, 0}, {0, 2, 1}}}", # 28: (square spiral)
"{{{1, 2, 0}, {1, 2, 1}}, {{0, 1, 0}, {0, 1, 1}}}", # 29: loopy growth with holes
"{{{1, 2, 1}, {0, 8, 1}}, {{1, 1, 0}, {0, 1, 0}}}", # 30: Lanton's Ant drawn with squares
"{{{1, 2, 1}, {0, 2, 0}}, {{0, 8, 1}, {1, 8, 0}}}", # 31: growth with curves and blocks
"{{{1, 2, 1}, {0, 2, 0}}, {{0, 1, 0}, {1, 2, 1}}}", # 32: distracted spiral builder
"{{{1, 2, 1}, {0, 2, 1}}, {{1, 1, 0}, {1, 1, 1}}}", # 33: cauliflower stalk (45 deg highway)
"{{{1, 2, 1}, {1, 8, 1}}, {{1, 2, 1}, {0, 2, 0}}}", # 34: worm trails (eventually turns cyclic!)
"{{{1, 2, 1}, {1, 1, 0}}, {{1, 1, 0}, {0, 1, 1}}}", # 35: eventually makes a two-way highway!
"{{{1, 2, 1}, {1, 2, 0}}, {{0, 1, 0}, {0, 1, 0}}}", # 36: almost symmetric mould bloom
"{{{1, 2, 1}, {1, 2, 0}}, {{0, 2, 0}, {1, 1, 1}}}", # 37: makes a 1 in 2 gradient highway
"{{{1, 2, 1}, {1, 2, 1}}, {{1, 8, 1}, {0, 2, 0}}}", # 38: immediately makes a 1 in 3 highway
"{{{0, 2, 1}, {1, 2, 1}}, {{0, 8, 2}, {0, 8, 0}}, {{1, 2, 2}, {1, 8, 0}}}", # 39: squares and diagonals growth
"{{{1, 8, 1}, {0, 1, 0}}, {{0, 2, 2}, {1, 8, 0}}, {{1, 2, 1}, {1, 1, 0}}}", # 40: streak at approx. an 8.1 in 1 gradient
"{{{1, 8, 1}, {0, 1, 2}}, {{0, 2, 2}, {1, 1, 1}}, {{1, 2, 1}, {1, 1, 0}}}", # 41: streak at approx. a 1.14 in 1 gradient
"{{{1, 8, 1}, {1, 8, 1}}, {{1, 1, 0}, {0, 1, 2}}, {{0, 8, 1}, {1, 1, 1}}}", # 42: maze-like growth
"{{{1, 8, 2}, {0, 2, 0}}, {{1, 8, 0}, {0, 2, 0}}, {{0, 8, 0}, {0, 8, 1}}}", # 43: growth by cornices 
"{{{1, 2, 0}, {0, 2, 2}}, {{0, 8, 0}, {0, 2, 0}}, {{0, 1, 1}, {1, 8, 0}}}", # 44: makes a 1 in 7 highway
"{{{1, 2, 1}, {0, 8, 0}}, {{1, 2, 2}, {0, 1, 0}}, {{1, 8, 0}, {0, 8, 0}}}", # 45: makes a 4 in 1 highway
# source: http://www.mathpuzzle.com/Turmite5.nb
# via: http://www.mathpuzzle.com/26Mar03.html
# "I wondered what would happen if a turmite could split as an action... say Left and Right.  
#  In addition, I added the rule that when two turmites met, they annihilated each other.
#  Some interesting patterns came out from my initial study. My main interest is finding 
#  turmites that will grow for a long time, then self-annihilate."
"{{{1, 8, 0}, {1, 2, 1}}, {{0, 10, 0}, {0, 8, 1}}}",  # 46: stops at 11 gens
"{{{1, 8, 0}, {1, 2, 1}}, {{1, 10, 0}, {1, 8, 1}}}",  # 47: stops at 12 gens
"{{{1, 15, 0}, {0, 2, 1}}, {{0, 10, 0}, {0, 8, 1}}}", # 48: snowflake-like growth
"{{{1, 2, 0}, {0, 15, 0}}}",                          # 49: blob growth
"{{{1, 3, 0}, {0, 3, 0}}}",                           # 50: (spiral) - like SDSR-Loop on a macro level
"{{{1, 3, 0}, {0, 1, 0}}}",                           # 51: (spiral)
"{{{1, 10, 0}, {0, 1, 0}}}",                          # 52: snowflake-like growth
"{{{1, 10, 1}, {0, 1, 1}}, {{0, 2, 0}, {0, 0, 0}}}",  # 53: interesting square growth
"{{{1, 10, 1}, {0, 5, 1}}, {{1, 2, 0}, {0, 8, 0}}}",  # 54: interesting square growth
"{{{1, 2, 0}, {0, 1, 1}}, {{1, 2, 0}, {0, 6, 0}}}",   # 55: stops at 14 gens
"{{{1, 2, 0}, {1, 1, 1}}, {{0, 2, 0}, {0, 11, 0}}}",  # 56: grows with many highways
"{{{1, 2, 1}, {0, 2, 1}}, {{1, 15, 0}, {1, 8, 0}}}",  # 57: divided square growth
"{{{1, 2, 0}, {2, 8, 2}, {1, 1, 1}}, {{1, 1, 2}, {0, 2, 1}, {2, 8, 1}}, {{0, 11, 0}, {1, 1, 1}, {0, 2, 2}}}", # 58: wedge-shaped semi-chaotic growth
"{{{1, 2, 0}, {2, 8, 2}, {2, 1, 1}}, {{1, 1, 2}, {1, 1, 1}, {1, 8, 1}}, {{2, 10, 0}, {2, 8, 1}, {2, 8, 2}}}"  # 59: moss-like growth with internal raindrops
]
# N.B. the images in the demonstration project http://demonstrations.wolfram.com/Turmites/
# are mirrored - e.g. Langton's ant turns left instead of right.
# (Also example #45 isn't easily accessed in the demonstration, you need to open both 'advanced' controls,
#  then type 45 in the top text edit box, then click in the bottom one.)

spec = golly.getstring(
'''This script will create a Turmite CA for a given specification.

Enter a number (1-59) for an example Turmite from Ed Pegg Jr.'s (extended) library.
(see http://demonstrations.wolfram.com/Turmites/ or the code of this script)

Otherwise enter a specification string: a curly-bracketed table of n_states rows
and n_colors columns, where each entry is a triple of integers. 
The elements of each triple are:
a: the new color of the square
b: the direction(s) for the Turmite to turn (1=noturn, 2=right, 4=u-turn, 8=left)
c: the new internal state of the Turmite

Example:
{{{1, 2, 0}, {0, 8, 0}}}
(example pattern #1)
Has 1 state and 2 colors. The triple {1,2,0} says: 
1. set the color of the square to 1
2. turn right (2)
3. adopt state 0 (no change) and move forward one square
This is Langton's Ant.

CAUTION! Large tables take a long time to generate!

Enter integer or string:''', str(18), 'Enter Turmite specification:')

if spec.isdigit():
    spec = EdPeggJrTurmiteLibrary[int(spec)-1] # (his demonstration project UI is 1-based)

# convert the specification string into action_table[state][color]
# (convert Mathematica code to Python and run eval)
action_table = eval(string.replace(string.replace(spec,'}',']'),'{','['))
n_states = len(action_table)
n_colors = len(action_table[0])
# (N.B. The terminology 'state' here refers to the internal state of the finite
#       state machine that each Turmite is using, not the contents of each Golly
#       cell. We use the term 'color' to denote the symbol on the 2D 'tape'. The
#       actual 'Golly state' in this emulation of Turmites is given by the 
#       "encoding" section below.)

# TODO: check table is full and valid

total_states = n_colors+n_colors*n_states*4

# problem if we try to export more than 255 states
if total_states > 255:
    golly.warn("Number of states required exceeds Golly's limit of 255.")
    golly.exit()

# encoding: 
# (0-n_colors: empty square)
def encode(c,s,d):
    # turmite on color c in state s facing direction d
    return n_colors + 4*(n_states*c+s) + d

# decoding:
def has_turmite(s): 
    return s>=n_colors
def get_direction(s): # assume has_turmite(s)
    return (s-n_colors)%4 
def get_state(s): # assume has_turmite(s)
    return (((s-n_colors)-get_direction(s))/4)%n_states
def get_color(s):
    if not has_turmite(s): return s
    else: return int((s-n_colors) / (n_states*4))

# http://rightfootin.blogspot.com/2006/09/more-on-python-flatten.html
def flatten(l, ltypes=(list, tuple)):
    ltype = type(l)
    l = list(l)
    i = 0
    while i < len(l):
        while isinstance(l[i], ltypes):
            if not l[i]:
                l.pop(i)
                i -= 1
                break
            else:
                l[i:i + 1] = l[i]
        i += 1
    return ltype(l)
    
# convert the string to a form we can embed in a filename
spec_string = ''.join(map(str,map(lambda x:hex(x)[2:],flatten(action_table)))) 
# (ambiguous but we have to try something)

def turmite_transition_function(c,nbors): # nbors: [n,e,s,w]
    new_color = get_color(c) # unless something changes it
    if has_turmite(c):
        # color of this square changes as the turmite leaves
        new_color = action_table[get_state(c)][get_color(c)][0]
    is_turmite_arriving = False # until we discover otherwise
    turmite_new_dir = 0
    turmite_new_state = 0
    for from_dir in range(4):
        from_square = nbors[from_dir]
        if not has_turmite(from_square):
            continue
        turmite_currently_facing = get_direction(from_square)
        turmite_turn_action = action_table[get_state(from_square)][get_color(from_square)][1]
        # try all the possible actions to see if any of them (max 1) leads the turmite here
        coming_here = False
        for action in [1,2,4,8]:
            if turmite_turn_action & action:  # (actions are bitwise combined)
                # turmite is performing this action (possibly among others)
                turmite_new_dir = turn[action][turmite_currently_facing]
                if from_dir == opposite_dirs[turmite_new_dir]: # e.g. Turmite to the N about to move S
                    coming_here = True
                    break # (at most one action will lead the turmite here)
        # is a turmite arriving from this direction?
        if coming_here:
            if is_turmite_arriving:
                # multiple turmites arriving: they annihilate each other
                is_turmite_arriving = False
                break # (we don't need to check any other neighbors)
            is_turmite_arriving = True
            turmite_new_state = action_table[get_state(from_square)][get_color(from_square)][2]
    if is_turmite_arriving:
        return encode(new_color,turmite_new_state,turmite_new_dir)
    else:
        return new_color
        
# a wrapper for the transition function, to re-order the params
# (order for four neighbors is n, w, e, s, c)
def f(a): return turmite_transition_function(a[4],[a[0],a[2],a[3],a[1]])
    
# Tom Rokicki's rule tree generation code:
class GenerateRuleTree:

    def __init__(self,numStates,numNeighbors,f):
    
        self.numParams = numNeighbors + 1 ;
        self.world = {}
        self.r = []
        self.params = {}
        self.nodeSeq = 0
        self.numStates = numStates
        self.numNeighbors = numNeighbors
        self.f = f
        
        self.recur(self.numParams)

    def getNode(self,n):
        if n in self.world:
            return self.world[n]
        else:
            new_node = self.nodeSeq
            self.nodeSeq += 1
            self.r.append(n)
            self.world[n] = new_node
            return new_node

    def recur(self,at):
        if at == 0:
            return self.f(self.params)
        n = str(at)
        for i in range(self.numStates):
            if at==self.numParams:
                golly.show('Generating rule tree: '+str(100*i/self.numStates)+'%...')
                golly.update()
            self.params[self.numParams-at] = i
            n += " " + str(self.recur(at-1))
        return self.getNode(n)
      
    def writeRuleTree(self,name):
        # we write to a rule table file in user's rules directory
        f=open(golly.getdir('rules')+name+'.tree', 'w')
        f.write("num_states=" + str(self.numStates)+"\n")
        f.write("num_neighbors=" + str(self.numNeighbors)+"\n")
        f.write("num_nodes=" + str(len(self.r))+"\n")
        for rule in self.r:
            f.write(rule+"\n")
        f.close()

# generate the rule tree from the transition function
gen = GenerateRuleTree(total_states,4,f)
gen.writeRuleTree(prefix+'-'+spec_string)

# now we can switch to the new rule
# problem: sometimes the file is still writing when we try to read it
time.sleep(0.5)            # perhaps this will avoid the problem?
golly.setrule('b1/s1')     # force a rule change
golly.setrule(prefix+'-'+spec_string)
golly.new(prefix+'-demo.rle')
golly.setcell(0,0,n_colors) # start with an ant facing N
golly.show('Created '+prefix+'-'+spec_string+'.table, and selected this rule.')
