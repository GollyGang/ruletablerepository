The Squaredance rule
by Dean Hickerson, 1/8/2011
---------------------------

Squaredance is a rule in which rectangles grow and shrink pseudorandomly.
We start with a hollow rectangle whose cells are in states 1 and 2; these
represent bits 0 and 1.  The bits obey the 1-dimensional rule 90, with a cell
changing to the XOR of its two orthogonal neighbors.  Next we change one of
the cells to state 3 (the "head" state), and change its clockwise neighbor to
either state 5 or 6 (the "tail" states).  This pair of cells (the "looper")
moves counterclockwise around the rectangle.  (The rule has 90 degree
rotational symmetry, but is not symmetric under reflections.)  Whenever the
looper reaches a corner, it causes the edge that it just traversed to shift 1
cell outward or inward, depending on what bit is in front of it.  (Exception: 
If the width in the direction perpendicular to the edge is 3, then the edge
shifts outward no matter what bit the looper sees.  This prevents the
rectangle from collapsing.  There's an additional head state to take care of
this case.)

Spaceships
----------
If the rectangle starts with all of its bits in state 1 and the looper's tail
in state 5, then it will shrink to size 3x3, at which point it's a diagonal
spaceship with speed c/10:

[File "8x18.rle"]

#C An 8x18 rectangle becomes a c/10 diagonal spaceship in gen 195
x = 18, y = 8, rule = Squaredance
18A$A16.A$A16.A$A16.A$A16.A$A16.A$E16.A$C17A!

Otherwise, the pattern may grow and shrink for a while.  It might eventually
lose all of its state-2 cells and become the c/10 spaceship, or it might
become an oscillator or spaceship with a mixture of cells in states 1 and 2,
or it might grow forever.  I haven't found any oscillators or patterns that
grow forever, but there are infinitely many spaceships.  Here are 12 of them
which I've seen arise from random starting patterns; 9 move diagonally, 1
moves orthogonally, and 2 are slow knightships:

[File "12_spaceships.rle"]

#C Collection of 12 spaceships; the second and third are the most common:
#C 4c/764 diagonal,  (1,9)c/6230,  c/10 diagonal,  c/18 diagonal,
#C c/58 diagonal,  c/70 diagonal,  2c/36 diagonal (2 versions), 
#C (44,24)c/555276,  2c/52 diagonal,  c/28 diagonal, 8c/576 orthogonal
x = 290, y = 65, rule = Squaredance
278.3ABC$278.A3.F$278.A3.A$202.CF6A68.B3.B$202.A6.A68.A3.A$174.3AB24.
5AB2A68.A3.B$148.ABC23.B2.A100.ABABA$148.A.F23.A2.B$57.H2A61.ABCEG22.
A.A23.A2.A$56.A2.B61.B3.B22.A.A23.A2.A$10.CFABAB40.F2.A37.CEG21.A3.A
22.A.A23.E2.A24.CF3AB2A$10.B4.A40.C2.B37.A.A21.A3.A22.A.A23.C2.A24.A
6.A$10.5AB40.4A37.3A21.5A22.3A23.B3A24.5AB2A8$C.C3.2C4.C2.3C.3C.C.C
11.C2.C6.3C2.C4.2C4.C2.3C.3C.3C.3C11.2C4.C2.C.3C11.2C4.C2.C.3C11.2C4.
C2.3C.3C11.2C4.C2.3C.3C10.3C3.2C4.C2.3C.3C11.C2.C.C.C.C6.3C.C.C2.C4.
2C4.C2.3C.3C.3C.3C.3C.3C$C.C2.C6.C4.C.C3.C.C10.C3.C6.C.C3.C2.C6.C2.C
5.C3.C.C.C10.C6.C2.C.C.C10.C6.C2.C.C.C10.C6.C2.C3.C.C10.C6.C4.C.C.C
12.C2.C6.C4.C.C12.C3.C.C.C.C8.C.C.C3.C2.C6.C2.C3.C3.C5.C3.C.C$3C2.C5.
C5.C.3C.3C10.C3.C6.3C3.C2.C5.C3.3C.3C.3C.C.C10.C5.C3.C.C.C10.C5.C3.C.
3C10.C5.C3.3C.3C10.C5.C5.C.C.C10.3C2.C5.C3.3C.3C10.C3.3C.3C6.3C.3C3.C
2.C5.C3.3C.3C.3C.3C3.C.3C$2.C2.C4.C6.C.C.C3.C10.C3.C2.2C4.C3.C2.C4.C
4.C.C.C5.C.C.C10.C4.C4.C.C.C10.C4.C4.C.C.C10.C4.C6.C.C.C10.C4.C6.C.C.
C10.C4.C4.C6.C.C.C10.C5.C3.C2.2C2.C5.C3.C2.C4.C6.C3.C3.C.C5.C.C.C$2.C
3.2C2.C6.C.3C3.C11.C2.C2.2C2.3C2.C4.2C2.C4.3C.3C.3C.3C11.2C2.C4.C.3C
11.2C2.C4.C.3C11.2C2.C4.3C.3C11.2C2.C6.C.3C10.3C3.2C2.C4.3C.3C11.C4.C
3.C2.2C2.3C3.C2.C4.2C2.C4.3C.3C.3C.3C3.C.3C$44.C196.C$43.C196.C14$3C
3.2C4.C2.3C.3C11.2C4.C2.3C.3C21.AB2A$2.C2.C6.C2.C5.C10.C6.C4.C.C.C21.
B2.A$3C2.C5.C3.3C.3C10.C5.C3.3C.3C21.A2.B$C4.C4.C6.C.C12.C4.C4.C3.C.C
21.A2.A$3C3.2C2.C4.3C.3C11.2C2.C4.3C.3C21.A2.B$70.A2.A$70.A2.B$70.B2.
A$70.A2.A$70.E2.A$70.C2.A$70.2ABA$6.3ACF5A21.AB3AB$6.A8.A21.A4.A$6.A
8.A21.A4.A$6.2AG6.B21.A4.A$9.ABABABA21.A4.B$37.A4.A$37.A4.B$37.A4.A$
37.H4.B16.3C3.2C4.C2.3C.3C.3C$38.AEC2A16.C.C2.C6.C2.C5.C.C$59.3C2.C5.
C3.3C3.C.3C$59.C.C2.C4.C6.C3.C.C.C$59.3C3.2C2.C4.3C3.C.3C!

The 2c/36 spaceships are the smallest and fastest of an infinite set of
diagonal spaceships with speeds of the form  2c/(2^n + 4),  for  n >= 5.  For
each value of n, there are  2^(2^(n-2) - 7)  different spaceships of that
speed.  The pattern below shows 2 of them for each n from 5 to 10.  The top
one in each pair has only one 1-bit; the bottom one has the maximum possible
number of 1-bits, namely  2^(n-2) - 5.  Any combination of 1-bits between the
minimum and maximum gives a spaceship.  There are  2^(2^(n-2) - 6) 
possibilities, which give half that many spaceships, since each occurs twice,
half a period out of phase.

[File "inf_spaceships.rle"]

#C 12 diagonal spaceships, 2 for each speed of the form
#C 2c/(2^n + 4),  5 <= n <= 10
x = 256, y = 80, rule = Squaredance
CF6A$A6.A$5AB2A5$CF3ABAB$A6.A$5AB2A5$CF14A$A14.A$5AB10A5$CF3ABABABABA
BAB$A14.A$5AB3ABABABAB5$CF30A$A30.A$5AB26A5$CF3ABABABABABABABABABABAB
ABABAB$A30.A$5AB3ABABABABABABABABABABABAB5$CF62A$A62.A$5AB58A5$CF3ABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABAB$A62.A$5AB3A
BABABABABABABABABABABABABABABABABABABABABABABABABABABAB5$CF126A$A126.
A$5AB122A5$CF3ABABABABABABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABAB
$A126.A$5AB3ABABABABABABABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABAB5$CF
254A$A254.A$5AB250A5$CF3ABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABAB
ABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABAB
$A254.A$5AB3ABABABABABABABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABAB
ABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABABA
BABABABABABABABABABABABABABABABABABABABABABABABABABAB!

I've seen many members of this set arise naturally, with n up to 10.  Here's
the one with n=10:

[File "2c1028_pred.rle"]

#C 6x10 pattern become 2c/1028 diagonal spaceship in gen 7,776,477
x = 10, y = 6, rule = Squaredance
2ABAB5A$A8.A$A8.A$A8.A$E8.A$CB8A!

Random walk
-----------
For a typical pattern, if we plot the points (w(n),h(n)) where w(n) is the
width and h(n) is the height of the rectangle after the n'th time that the
looper hits a corner, then we get something that resembles a simple random
walk in one quadrant of the 2-dimensional lattice.  It's known that such a
walk returns to the origin infinitely often, with probability 1.  If the
random walk is an accurate model of what's happening here, then every pattern
should eventually repeat, as either an oscillator or a spaceship.  However,
the expected time for a random walk to return to the origin is infinite, so we
might have to wait a long time for that to happen.

Methuselahs
-----------
So far every pattern that I've tried has eventually turned into a spaceship,
although one took more than 8 billion generations and ran for 5 days on my
computer.  As in Life, there are several common methuselahs; many patterns
turn into one of these or one of their early descendants:

[File "common_methuselahs.rle"]

#C Collection of 4 common methuselahs
#C 3x6 pattern becomes (1,9)c/6230 spaceship in gen 237,881
#C 3x3 pattern becomes c/10 diagonal spaceship in gen 788,635
#C 4x3 pattern becomes c/10 diagonal spaceship in gen 3,035,098
#C 3x4 pattern becomes (1,9)c/6230 spaceship in gen 6,130,719
x = 386, y = 194, rule = Squaredance
28.CEAB2A329.2AC$28.A4.A329.A.F$28.ABAB2A329.3A7$3D.3D.3D4.3D.3D.D7.D
7.D2.D6.3D2.D4.2D4.D2.3D.3D.3D.3D248.3D.3D.3D4.3D.3D.3D7.D7.2D4.D2.D.
3D$2.D3.D3.D4.D.D.D.D.D8.D5.D3.D6.D.D3.D2.D6.D2.D5.D3.D.D.D250.D.D.D.
D.D4.D5.D.D10.D5.D6.D2.D.D.D$3D.3D3.D4.3D.3D.D4.6D4.D3.D6.3D3.D2.D5.D
3.3D.3D.3D.D.D250.D.3D.3D4.3D.3D.3D4.6D4.D5.D3.D.D.D$D5.D3.D.2D.D.D.D
.D.D8.D5.D3.D2.2D4.D3.D2.D4.D4.D.D.D5.D.D.D250.D.D.D.D.D.2D.D.D3.D3.D
8.D5.D4.D4.D.D.D$3D.3D3.D.2D.3D.3D.D7.D7.D2.D2.2D2.3D2.D4.2D2.D4.3D.
3D.3D.3D250.D.3D.3D.2D.3D.3D.3D7.D7.2D2.D4.D.3D$13.D32.D297.D$12.D32.
D297.D162$39.2AB$39.A.A290.CEAB$39.B.B290.B2.A$39.AEC290.4A7$3D4.3D.
3D.3D4.3D.3D.3D7.D7.2D4.D2.D.3D236.3D4.D.3D.3D4.3D.D.3D7.D7.D2.D6.3D
2.D4.2D4.D2.3D.3D.3D.3D$2.D4.D.D3.D.D6.D.D.D.D.D.D8.D5.D6.D2.D.D.D
236.D6.D3.D.D.D6.D.D.D.D8.D5.D3.D6.D.D3.D2.D6.D2.D5.D3.D.D.D$3D4.D.D.
3D.3D4.D.D.3D.3D4.6D4.D5.D3.D.D.D236.3D4.D.3D.D.D6.D.D.3D4.6D4.D3.D6.
3D3.D2.D5.D3.3D.3D.3D.D.D$2.D.2D.D.D3.D3.D.2D.D.D3.D.D.D8.D5.D4.D4.D.
D.D236.D.D.2D.D3.D.D.D.2D3.D.D3.D8.D5.D3.D2.2D4.D3.D2.D4.D4.D.D.D5.D.
D.D$3D.2D.3D.3D.3D.2D.3D.3D.3D7.D7.2D2.D4.D.3D236.3D.2D.D.3D.3D.2D3.D
.D.3D7.D7.D2.D2.2D2.3D2.D4.2D2.D4.3D.3D.3D.3D$5.D14.D282.D12.D32.D$4.
D14.D282.D12.D32.D!


Here are some more examples of methuselahs.  One of them runs for over 8
billion generations, and has maximum population over 5800.

[File "5_methuselahs.rle"]

#C Collection of 5 methuselahs:
#C 7x7 pattern becomes 2c/36 diagonal spaceship in gen 14,125,832
#C 7x7 pattern becomes (1,9)c/6230 spaceship in gen 28,467,394
#C 9x3 pattern becomes c/10 diagonal spaceship in gen 56,287,685
#C 7x7 pattern becomes (1,9)c/6230 spaceship in gen 231,955,479
#C 5x11 pattern becomes (1,9)c/6230 spaceship in gen 8,397,468,736
x = 1434, y = 628, rule = Squaredance
1411.ABC$1411.A.E$37.5ABC792.ABABABC568.A.A$37.A5.E792.A5.F568.A.B$
37.A5.A792.A5.A568.A.A$37.B5.A792.A5.A568.A.A$37.A5.A792.A5.A568.A.A$
37.A5.A792.A5.A568.A.A$37.ABAB3A792.5ABA568.3A13$D.D.D4.D.3D.3D4.3D.
3D.3D7.D6.3D3.2D4.D2.3D.3D726.3D.3D4.D.D.3D.3D4.3D.3D.D.D7.D7.D2.D6.
3D2.D4.2D4.D2.3D.3D.3D.3D477.3D.3D4.3D.3D.3D4.3D.3D.3D7.D7.2D4.D2.D.
3D$D.D.D4.D3.D.D6.D.D3.D3.D8.D7.D2.D6.D4.D.D730.D.D.D4.D.D.D5.D6.D.D.
D.D.D8.D5.D3.D6.D.D3.D2.D6.D2.D5.D3.D.D.D477.D3.D8.D.D.D3.D4.D3.D.D.D
10.D5.D6.D2.D.D.D$D.3D4.D.3D.3D4.3D.3D.3D4.6D4.3D2.D5.D3.3D.3D726.3D.
3D4.3D.3D3.D4.3D.3D.3D4.6D4.D3.D6.3D3.D2.D5.D3.3D.3D.3D.D.D477.3D.3D
4.3D.3D3.D4.3D.3D.3D4.6D4.D5.D3.D.D.D$D3.D.2D.D.D5.D.2D.D.D3.D.D10.D
5.D4.D4.D6.D.D.D726.D3.D.D.2D3.D.D.D3.D.2D3.D3.D3.D8.D5.D3.D2.2D4.D3.
D2.D4.D4.D.D.D5.D.D.D479.D.D.D.2D.D3.D.D3.D.2D.D.D.D.D3.D8.D5.D4.D4.D
.D.D$D3.D.2D.D.3D.3D.2D.3D.3D.3D7.D6.3D3.2D2.D4.3D.3D726.3D.3D.2D3.D.
3D3.D.2D.3D.3D3.D7.D7.D2.D2.2D2.3D2.D4.2D2.D4.3D.3D.3D.3D477.3D.3D.2D
.3D.3D3.D.2D.3D.3D.3D7.D7.2D2.D4.D.3D$7.D12.D783.D14.D34.D522.D14.D$
6.D12.D783.D14.D34.D522.D14.D425$43.3AB2AC$43.A5.F$43.A5.A$43.A5.A$
43.A5.A$43.A5.A$43.AB3ABA13$3D.3D.D4.3D.3D.3D4.D.D.3D.3D7.D7.D2.D6.3D
2.D4.2D4.D2.3D.3D.3D.3D$2.D3.D.D4.D.D.D3.D6.D.D3.D.D.D8.D5.D3.D6.D.D
3.D2.D6.D2.D5.D3.D.D.D$3D.3D.D4.3D.3D.3D4.3D3.D.3D4.6D4.D3.D6.3D3.D2.
D5.D3.3D.3D.3D.D.D$D5.D.D.2D3.D3.D3.D.2D3.D3.D3.D8.D5.D3.D2.2D4.D3.D
2.D4.D4.D.D.D5.D.D.D$3D.3D.D.2D.3D.3D.3D.2D3.D3.D.3D7.D7.D2.D2.2D2.3D
2.D4.2D2.D4.3D.3D.3D.3D$11.D14.D34.D$10.D14.D34.D127$1377.7ABABC$
1377.A9.F$1377.A9.B$1377.B9.A$1377.ABABAB3ABA13$1327.3D4.3D.3D.3D4.D.
D.3D.3D4.3D.3D.3D7.D7.D2.D6.3D2.D4.2D4.D2.3D.3D.3D.3D$1327.D.D6.D.D.D
3.D4.D.D.D3.D.D6.D3.D.D10.D5.D3.D6.D.D3.D2.D6.D2.D5.D3.D.D.D$1327.3D
4.3D.3D3.D4.3D.3D.3D6.D.3D.3D4.6D4.D3.D6.3D3.D2.D5.D3.3D.3D.3D.D.D$
1327.D.D.2D3.D3.D3.D.2D3.D.D.D.D.D.2D3.D3.D.D.D8.D5.D3.D2.2D4.D3.D2.D
4.D4.D.D.D5.D.D.D$1327.3D.2D.3D.3D3.D.2D3.D.3D.3D.2D3.D.3D.3D7.D7.D2.
D2.2D2.3D2.D4.2D2.D4.3D.3D.3D.3D$1332.D14.D14.D34.D$1331.D14.D14.D34.
D!

Irrelevant bits
---------------
Only half of the bits in a pattern have any effect on its growth, namely those
in cells of the same color as the tail cell in a checkerboard coloring of the
plane.  I've tweaked the transition rules so that the irrelevant cells tend to
change to 0-bits.  If the pattern ever has height or width 3, then all of the
irrelevant bits will change to 0-bits; otherwise some 1-bits may remain, a
short distance ahead of the looper.

[File "irrel_7x7.rle"]

#C These two 7x7 patterns differ only in their irrelevant bits, but
#C they don't become identical until gen 1682.  They become a
#C (1,9)c/6230 spaceship in gen 1913.
x = 32, y = 7, rule = Squaredance
5ABC18.4A2BC$A5.E18.A5.E$A5.A18.A5.A$B5.B18.B5.B$A5.A18.A5.A$A5.A18.A
5.A$ABAB3A18.ABAB3A!

Four of the known spaceships never have height or width 3, and can keep one or
two irrelevant 1-bits forever:

[File "irrel_spaceships.rle"]

#C Multiple versions of the c/18, c/70, 2c/52, and c/28 spaceships
x = 49, y = 124, rule = Squaredance
5.2BCEG$5.B3.B$5.B3.A$5.A3.A$5.5A6$5.ABCEG$5.B3.B$5.B3.A$5.A3.A$5.5A
28.3AB$38.B2.A$38.A2.B$38.A2.A$38.A2.A$38.E2.A$5.2BCEG28.C2.A$5.B3.B
28.2B2A$5.A3.A$5.A3.A$5.5A3$38.3AB$38.B2.A$38.A2.B$5.ABCEG28.A2.A$5.B
3.B28.A2.A$5.A3.A28.E2.A$5.A3.A28.C2.A$5.5A28.B3A8$.2C4.C2.C.3C18.2C
4.C2.3C.3C$C6.C2.C.C.C17.C6.C4.C.C.C$C5.C3.C.3C17.C5.C5.C.C.C$C4.C4.C
.C.C17.C4.C6.C.C.C$.2C2.C4.C.3C18.2C2.C6.C.3C11$3C3.2C4.C2.3C.3C11.2C
4.C2.3C.3C$2.C2.C6.C2.C5.C10.C6.C4.C.C.C$3C2.C5.C3.3C.3C10.C5.C3.3C.
3C$C4.C4.C6.C.C12.C4.C4.C3.C.C$3C3.2C2.C4.3C.3C11.2C2.C4.3C.3C8$5.7AB
3A21.AB3AB$5.B9.B21.A4.A$5.A9.A21.A4.A$5.B7AECA21.A4.A$37.A4.B$37.A4.
A$37.A4.B$37.A4.A$37.H4.B$5.7AB3A22.AEC2A$5.B9.B$5.A9.B$5.B7AECA3$37.
AB3AB$37.A4.A$37.A4.A$37.A4.A$37.A4.B$37.A4.A$37.A4.B$37.A4.A$37.H4.B
$38.AECAB6$37.AB3AB$37.A4.A$37.A4.A$37.A4.A$37.A4.B$37.A4.A$37.A4.B$
37.A4.B$37.H4.B$38.AEC2A6$37.AB3AB$37.A4.A$37.A4.A$37.A4.A$37.A4.B$
37.A4.A$37.A4.B$37.A4.B$37.H4.B$38.AECAB!

Height and width parity
-----------------------
I ran a bunch of random patterns of the same size, all with the looper
starting in the same position.  Many of them became c/10 spaceships; I was
surprised to see that the spaceships were all going northeast.  Similarly, all
the (1,9)c/6230 spaceships were going just east of north and all the 4c/764
spaceships were going northwest.  It turns out that this is easily explained:

Suppose that the looper is moving south along the west edge.  The north and
east edges may still be shifting outward or inward.  If you replace the looper
by bits, and let those edges finish shifting, the pattern will become a
rectangle again.  Define the "effective height and width" of the original
pattern to be the height and width of that rectangle.  When the looper goes
around a corner, either the effective height or the effective width will
change parity.  At the next 3 corners, the other dimension will change parity,
then the first one will change back, and then the second will change back. 
When the looper gets back to the west edge, both parities will be the same as
they were.  So we can separate patterns into 4 types, based on the parities
when the looper is on the west edge.  The type of a pattern never changes.

Rotating a pattern does change its type, so for a spaceship the type is
determined by its direction of motion.  In my experiments, all of the patterns
were of the same type, so the c/10 spaceships that some of them produced were
all going the same way.

I've rotated all of the patterns given above so that the effective width and
height are even when the looper is on the west edge.

Questions
---------
Are there any oscillators?  (A rectangle of bits, without a looper,
oscillates, but I'm only interested in patterns which have a looper.)

Can a pattern grow forever?  (Before settling on this rule, I tried several
variants; in many of them there were patterns that grew forever in some
predictable way.  But I haven't seen anything like that in this rule.)

Are there other infinite classes of spaceships?

The squaredance.random.py script
--------------------------------
This script is used to create random starting patterns.  There are two ways to
use it:

If there's a selection when the script is run, then a random pattern is
created in the selected rectangle.  Cells outside the rectangle are not
changed.

If there's no selection, then the user is prompted for 3 numbers (separated by
commas): H, W, C.  Then the current pattern is erased and C random patterns
are created, with height H and width W, separated by 1000 empty columns.

In each case, all of the irrelevant bits are set to bit 0, and the looper is
positioned so that the effective height and width will be even when the looper
is on the west edge.
