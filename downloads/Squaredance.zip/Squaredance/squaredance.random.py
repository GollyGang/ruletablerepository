# Create random rectangular loop in current selection.
# If no selection, prompt user for size and number of loops to create.
# Author: Dean Hickerson, 1/7/2011

from glife import *
from random import randrange

##########################################################################

def randbit():			# Random 0 or 1
   return randrange(0,2)

##########################################################################

def randpat(rmin, cmin, ht, wd):
# Creates random pattern in specified rectangle.

#####  Compute edge rows and columns.

   rmax = rmin + ht - 1
   cmax = cmin + wd - 1
   rrange = xrange(rmin, rmax+1)
   crange = xrange(cmin, cmax+1)

   #####  Compute locations for head and tail of looper.  Head is at
   #####  corner, chosen based on parities of width and height so that
   #####  all spaceships of same type will travel in same direction.
   #####  Tail is next cell clockwise from corner.

   if (ht&1)==0 and (wd&1)==0:	# Southwest corner
      rhead = rmax
      chead = cmin
      rtail = rhead-1
      ctail = chead

   if (ht&1)==1 and (wd&1)==0:	# Northwest corner
      rhead = rmin
      chead = cmin
      rtail = rhead
      ctail = chead+1

   if (ht&1)==1 and (wd&1)==1:	# Northeast corner
      rhead = rmin
      chead = cmax
      rtail = rhead+1
      ctail = chead

   if (ht&1)==0 and (wd&1)==1:	# Southeast corner
      rhead = rmax
      chead = cmax
      rtail = rhead
      ctail = chead-1

   def randcell(r,c):
   # If (r,c) has same color in checkerboard coloring as head cell,
   # return bit 0 (= state 1).  (These are the irrelevant bits, which
   # have no effect on the growth of the pattern.)  Otherwise return
   # random bit (state 1 or 2).
      if (r+c+rhead+chead) & 1 == 0:	return 1
      else:				return 1+randbit()

   #####  Clear rectangle

   for r in rrange:
      for c in crange:
         golly.setcell(c,r,0)

   #####  Set edge cells

   for r in rrange:
      golly.setcell(cmin, r, randcell(r,cmin))
      golly.setcell(cmax, r, randcell(r,cmax))

   for c in crange:
      golly.setcell(c, rmin, randcell(rmin,c))
      golly.setcell(c, rmax, randcell(rmax,c))

   #####  Add looper, arriving at corner.

   golly.setcell(chead, rhead, 3)
   golly.setcell(ctail, rtail, 5+randbit())

##########################################################################

selrect = golly.getselrect()
if len(selrect) > 0:	# Create random pattern in selection
   wd = selrect[2]
   ht = selrect[3]

   if wd<3 or ht<3:	golly.exit("Selection must be at least 3 x 3.")

   golly.setrule("Squaredance")
   randpat(selrect[1], selrect[0], ht, wd)

else:			# Prompt for size and number of patterns to create
   input = golly.getstring('Warning:  Current pattern will be deleted.\n\n'
                           'Enter height, width, count:')
   args = input.split(',')

   if len(args)<>3 or not validint(args[0])\
   or not validint(args[1]) or not validint(args[2]):
      golly.exit('Input should be 3 numbers separated by commas.')

   golly.new("Random patterns")
   golly.setrule("Squaredance")

   ht = int(args[0])
   wd = int(args[1])
   count = int(args[2])

   if ht<3 or wd<3:
      golly.exit('Rectangle size must be at least 3 x 3.')

   for i in xrange(count):
      randpat(0, i*(wd+1000), ht, wd)
   golly.fit()