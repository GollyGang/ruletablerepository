# This scripts writes out a log file showing when gates have changed state.
# It is useful for debugging.

from glife import rect
from time import time
import golly as g
import random

oldsecs = time()

# these are the control gates that we monitor
control_gates = [
('A',(19424,-2991)),
('g4',(19632,-2892)),
('g5',(19632,-2839)),
('g6',(19632,-2790)),
('g7',(19632,-2945)),
('B',(20418,-3849)),#,(20418,-4168)), # we trust that the other is the same
('C',(20465,-4168)),
('D',(20465,-3849)),
('E',(19300,-1193)),
('F',(19188,-2993)),
('H',(18955,-1260)),#,(18890,-1232)),
('K',(20418,-3530)),
('M',(20592,-3211)),
('P',(20418,-2892)),
('t0',(16868,-3622)),
('t1',(16801,-3571)),
('t2',(16734,-3520)),
('t3',(16667,-3469)),
('t4',(16600,-3418)),
('t5',(16533,-3367)),
('t6',(16466,-3316)),
('t7',(16399,-3265)),
('t8',(16332,-3214)),
('t9',(16265,-3163)),
('t10',(16198,-3112)),
('t11',(16131,-3061)),
('t12',(16072,-3010)),
('u0',(17386,-4409)),
('u1',(17563,-4464)),
('u2',(17740,-4519)),
('u3',(17917,-4574)),
('u4',(16600,-2194)),
('u5',(16533,-2143)),
('u6',(16466,-2092)),
('u7',(16399,-2041)),
('u8',(16332,-1939)),
('u9',(16265,-1888)),
('u10',(16198,-1837)),
('u11',(16131,-1786)),
('v0',(18097,-1384)),
('v1',(18274,-1445)),
('v2',(18451,-1506)),
('v3',(18628,-1567)),
('v4',(16600,-1735)),
('v5',(16533,-1684)),
('v6',(16466,-1633)),
('v7',(16399,-1582)),
('v8',(16332,-1531)),
('v9',(16265,-1480)),
('v10',(16198,-1429)),
('v11',(16131,-1378)),
('f0',(17117,-4297)),
('0',(18891,-1193)),
('1',(18956,-1058))
]

# these are the control lines that we monitor using fake toggle gates
steps = [
('s4',(15985,-4334)),
('s3',(15985,-4232)),
('s6',(15985,-4130)),
('s7',(15985,-4028)),
('s8',(15985,-3926)),
('s10',(15985,-3824)),
('s11',(15985,-3722)),
('s0',(15985,-3671)),
('e0',(15985,-3620)),
('e1',(15985,-3569)),
('e2',(15985,-3518)),
('e3',(15985,-3467)),
('e4',(15985,-3416)),
('e5',(15985,-3365)),
('e6',(15985,-3314)),
('e7',(15985,-3263)),
('e8',(15985,-3212)),
('e9',(15985,-3161)),
('e10',(15985,-3110)),
('e11',(15985,-3059)),
('e12',(15985,-3008)),
('f1',(15985,-2957)),
('f2',(15985,-2906)),
('f3',(15985,-2855)),
('f4',(15985,-2804)),
('f5',(15985,-2753)),
('f6',(15985,-2702)),
('f7',(15985,-2651)),
('f8',(15985,-2600)),
('f9',(15985,-2549)),
('f10',(15985,-2498)),
('f11',(15985,-2447)),
('f12',(15985,-2396)),
('f13',(15985,-2345)),
('f14',(15985,-2294)),
('f15',(15985,-2243)),
('p4',(15985,-2192)),
('p5',(15985,-2141)),
('p6',(15985,-2090)),
('p7',(15985,-2039)),
('p8',(15963,-1937)), # (N.B. different x)
('p9',(15985,-1886)),
('p10',(15985,-1835)),
('p11',(15985,-1784)),
('q4',(15985,-1733)),
('q5',(15985,-1682)),
('q6',(15985,-1631)),
('q7',(15985,-1580)),
('q8',(15985,-1529)),
('q9',(15985,-1478)),
('q10',(15985,-1427)),
('q11',(15985,-1376))
]

gates = control_gates[:]
for s in steps:
	gates.append(s)

def get_gate_states():
    states = []
    for gate in gates:
        states.append(g.getcell(gate[1][0],gate[1][1]))
    return states

g.show('Monitoring gates... (ESC to stop)')
gate_states = get_gate_states()

f = open('codd_log.txt', 'w')
f.write(g.getgen()+':')
# write out all the gates
for i,gate in enumerate(gates):
    f.write('  '+gate[0]+':'+str(gate_states[i]))
f.write('\n')
stop_signal_detected = False
while not stop_signal_detected:
    new_gate_states = get_gate_states()
    if not gate_states == new_gate_states:
        f.write(g.getgen()+':')
        # write out the gates that have changed
        for i,gate in enumerate(gates):
            if not gate_states[i] == new_gate_states[i]:
                f.write('  '+gate[0]+':'+str(new_gate_states[i]))
                if gate[0]=='f0' and new_gate_states[i]==1:
                    stop_signal_detected = True
                if gate[0] in map(lambda x: x[0],steps):
                    g.show('Current step: '+gate[0])
        f.write('\n')
        f.flush() # the script will have to be aborted at some point
        gate_states = new_gate_states
    g.step()
    g.update()
    g.dokey(g.getkey())

g.show('Stop signal detected. Run halted.')

