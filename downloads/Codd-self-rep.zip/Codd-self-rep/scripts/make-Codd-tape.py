# =================================================
# A Golly script to write the program and data
# tapes for the Codd UCC. Load Codd-body.mc.gz
# and run this script, then set the machine running by first
# injecting the sheathing signal. Find the injection receiver
# in the bottom-left corner:
#
#      1   
#   1  1  1  1  1  1  1  1
#      1  
#
# and replace it with:
#
#   2  2  2
#   1  1  0  6  1  1  1  1
#   2  2  2
#
# and then (after sheathing has finished) the trigger signal:
#
#   2  2  2  2  2  2  2  2
#   1  0  7  1  1  1  1  1
#   2  2  2  2  2  2  2  2
#
# Note: current estimates are that this will take at least
# 1000 years to self-replicate. Please see the paper:
# Tim J. Hutton (2010) "Codd's self-replicating computer"
# Artificial Life. (to appear)
#
# Script license: public domain
#
# Contact: tim.hutton@gmail.com
# Derived from work on the Devore machine -
# thanks to Ron Hightower and John Devore
# =================================================

import golly as g
from glife import rect
from time import time

# -------------------------------------------------------
# parameters for this script:

write_tapes = True
# True: writes the full tapes needed to copy the structure
# False: (for testing) only compute the tape's length (faster)

# coordinates of first cell of data tape, relative to bottom-left

# For Codd-body.mc.gz:
X = 22252
Y = 4189

# -------------------------------------------------------

# the locations of the tapes on the parent machine that we will write to
program_tape_x = 20746
program_tape_y = -4019
marker_tape_x = 20746
marker_tape_y = -4055
data_tape_x = 20745
data_tape_y = -4121

# -------------------------------------------------------
# some functions:

# range from start to stop (either direction)
#   twoway_range(0,10,2)==[0,2,4,6,8]
#   twoway_range(0,-10,2)==[0,-2,-4,-6,-8]
def twoway_range(start,stop,step=1):
    return range(start,stop,(-1 if (stop-start)<0 else 1)*abs(step))

# range from start to stop including both end points (either direction)
#   inclusive_range(0,10,2)==[0,2,4,6,8,10]
#   inclusive_range(10,0,2)==[10,8,6,4,2,0]
#   inclusive_range(0,-10,2)==[0,-2,-4,-6,-8,-10]
def inclusive_range(start,stop,step=1):
    return twoway_range(start,stop+(-1 if (stop-start)<0 else 1)*abs(step),step)

def write_string(s):
    global program_tape_x, program_tape_y
    for c in s:
        if c=='1':
           g.setcell(program_tape_x,program_tape_y,1)
        elif not c=='0':
           g.exit('Bad char in string: '+s)
        program_tape_x += 1

def write_program(program):
    global program_tape_x, program_tape_y

    # find the destination indices for all labels
    labels = {}
    iPos = 0
    for c in program:
        if c[-1]==':':
            labels[c[:-1]]=iPos
        else:
            iPos += 1

    # remove all the labels
    program = [c for c in program if not c[-1]==':']

    # make a mark at the beginning of the marker tape
    g.setcell(marker_tape_x-1,marker_tape_y,1)
    # make a mark at the beginning of the program tape (start immediately)
    g.setcell(program_tape_x-1,program_tape_y,1)

    # write the program to the program and marker tapes
    for i,c in enumerate(program):
        g.setcell(program_tape_x,marker_tape_y,1)
        # (each command starts with a mark)
        if 'jump_if_one:' in c:
            write_string(jump_if_one)
            dest = labels[c[c.index(':')+1:]]
            write_string('1'*abs(dest)+'0')
        else:
            # a normal command
            write_string(c)

# ------------------------------------
# create the program:
# ------------------------------------

# Our data tape contains coded construction instructions:
# 11  : write a 1
# 10  : write a 0
# 01  : write N 0's (where N is the value below)
# 001 : end of row
# 000 : end of construction
#
# Each row is scanned from the left edge to the last 1. (A temporary marker
# is used at the beginning for retraction, so rows can be any length.) Because
# each row ends with a 1, we know that the sequence 000 cannot appear on the
# data tape until the very end. This allows us to detect (reading backwards)
# the 000 sequence, in order to know when to stop copying.
#
# For retracting vertically after construction another temporary marker is used.
#
# Following Ron Hightower's work (thanks Ron!) we copy the data tape first and
# then read it from the far end. The data read head is made slightly prominent
# to allow the 000 to be skipped (else it would be detected during tape-copy and
# would cause it to end), but read correctly from the blank space at the end of
# the data tape nearest the machine.
#
# The instruction set above was just one that I tried. I'm quite sure it is
# possible to do this more efficiently.

N=15 # approximately found through experiment to give the shortest data tape
# must match the "write N 0's" section of the program

# -------------------------------------------------------
# these are the commands available for the program:

toggle_C = '0001' # f1
toggle_D = '0010' # f2
extend = '0100' # f4
extend_left = '0101' # f5
extend_right = '0110' # f6
retract = '0111' # f7
retract_left = '1000' # f8
retract_right = '1001' # f9
mark = '1010' # f10
erase = '1011' # f11
jump_if_one = '1100' # f12
inject_sheath = '1110' # f14
inject_trigger = '1111' # f15
stop = '0000'

# -------------------------------------------------------

# http://rightfootin.blogspot.com/2006/09/more-on-python-flatten.html
def flatten(l, ltypes=(list, tuple)):
    ltype = type(l)
    l = list(l)
    i = 0
    while i < len(l):
        while isinstance(l[i], ltypes):
            if not l[i]:
                l.pop(i)
                i -= 1
                break
            else:
                l[i:i + 1] = l[i]
        i += 1
    return ltype(l)
    
program = flatten([
    toggle_C, # open C
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:extendup', # (always jumps)
    
    # ----- retract until marker (used for tape *and* construction) ----
    
    # (this routine is here for speed, it's the most heavily used)
    'retract_until:',
    erase, # remove dummy mark (includes a retract, which is useful here)
    extend_left,extend,'jump_if_one:done_retract',
    retract,retract_left,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:retract_until', # (always jumps)
    
    # ---------- data tape copying phase: ------------------------
    
    # == 1 ==
    'write1:',
    retract,retract_right, # pull D from the tape
    toggle_D, # close D
    toggle_C, # open C
    extend_right,mark,retract_right,
    toggle_D, # open D
    extend, # (both C and D open)
    toggle_C, # close C
    extend_right,extend, # move D to the tape
    'jump_if_one:write1',
    # == 0 ==
    retract,retract_right, # pull D from the tape
    toggle_C, # open C 
    extend, # (both C and D open)
    toggle_C, # close C
    extend_right,extend, # move D to the tape
    'jump_if_one:write1',
    # == 00 ==
    retract,retract_right, # pull D from the tape
    toggle_C, # open C
    extend, # (both C and D open)
    toggle_C, # close C
    extend_right,extend, # move D to the tape
    'jump_if_one:write1',
    # == 000 ==
    retract,retract_right, # pull D from the tape
    # -- end of copy --
    toggle_C, # open C (now both open)
    retract,retract, # we overshot (first (rightmost) bit on data tape is 1)
    toggle_D, # close D
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:retract_until', # (always jumps)
    
    # ---------- construction phase: ------------------------
    
    'nextcolumn:',
    erase,extend, # remove the dummy mark (erase includes a retract)
    toggle_C, # close C
    toggle_D, # open D
    retract,
    extend_right,extend, # move D to the tape
    'jump_if_one:1',
    # == 0 ==
    retract,retract_right, # pull D from the tape
    retract,
    extend_right,extend, # move D to the tape
    'jump_if_one:01',
    # == 00 ==
    retract,retract_right, # pull D from the tape
    retract,
    extend_right,extend, # move D to the tape
    'jump_if_one:001',
    # == 000 ==
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:doneconstructing', # (always jumps)
    # == 01 ==
    '01:',
    retract,retract_right, # pull D from the tape
    toggle_D, # close D
    # -- write N 0's --
    toggle_C, # open C
    # N=15:
    extend,extend,extend,extend,extend,extend,extend,extend,extend,extend,
    extend,extend,extend,extend,extend,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:nextcolumn', # (always jumps)
    # == 1 ==
    '1:',
    retract,retract_right, # pull D from the tape
    retract,
    extend_right,extend, # move D to the tape
    'jump_if_one:11',
    # == 10 ==
    retract,retract_right, # pull D from the tape
    toggle_D, # close D
    # -- write a 0 --
    toggle_C, # open C
    extend,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:nextcolumn', # (always jumps)
    # == 11 ==
    '11:',
    retract,retract_right, # pull D from the tape
    toggle_D, # close D
    # -- write a 1 --
    toggle_C, # open C
    extend_right,mark,retract_right,
    extend,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:nextcolumn', # (always jumps)
    # == 001 ==
    '001:',
    retract,retract_right, # pull D from the tape
    toggle_D, # close D
    # -- retract row --
    toggle_C, # open C
    mark, # dummy mark, to allow the unconditional jump below
    'jump_if_one:retract_until', # (always jumps)
    
    # ------------------------ subroutines (here for speed): -----------------
    
    # retract vertically after construction
    'retractcolumn:',
    erase, # remove the dummy mark (includes a retract which is useful here)
    extend_left,extend,'jump_if_one:inject',
    retract,retract_left,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:retractcolumn', # (always jumps)

    # after retraction: decide whether was tape copying or construction row
    'done_retract:',
    erase,retract_left,retract,extend_left,extend,
    'jump_if_one:retractdown', # was retracting after tape copy
    # was retracting after construction row
    retract,retract_left,retract,retract,retract_right,
    extend, # move up for the next row
    # move into writing position
    extend_right,extend,extend,extend,
    # (make a mark at the start of the row for retraction)
    extend_left,extend,mark,retract,retract_left,
    mark, # dummy mark to allow unconditional jump
    'jump_if_one:nextcolumn', # (always jumps)
    
    # extend the C-arm up to copy the tape
    'extendup:', 
    erase, # (remove the dummy mark)
    # move the construction arm into the starting position
    extend_left,
    extend,extend,extend,extend,extend,
    extend,extend,extend,extend,extend,extend,extend,extend,extend,extend,
    extend,extend,extend,extend,extend,extend,extend,extend,extend,extend,
    # tape X:
    extend_right,
    [extend]*(X-3),
    # tape Y:
    extend_left,
    [extend]*(Y+6),
    # move into writing position
    extend_right,
    extend,extend,extend,
    # (make a double mark at the start of the copy for retraction)
    extend_left,extend,mark,retract,retract_left,
    extend,
    extend_left,extend,mark,retract,retract_left,
    # prepare for reading the next bit
    toggle_C, # close C
    toggle_D, # open D
    'jump_if_one:write1',   # (always jumps; we know that the tape ends in 001)
    
    # pull the C-arm down after copying the tape
    'retractdown:', 
    erase,retract_left,
    retract,retract,retract,
    retract_right,
    # tape Y:
    [retract]*(Y+6),
    retract_left,
    # tape X:
    [retract]*(X-3),
    retract_right,
    extend,extend,extend,extend,extend,extend,extend,extend,
    # (make a mark at the bottom-left for final retraction)
    extend_left,extend,mark,retract,retract_left,
    # move into writing position
    extend_right,extend,extend,extend,
    # (make a mark at the start of the row for retraction)
    extend_left,extend,mark,retract,retract_left,
    mark, # dummy mark, to allow the unconditional jump
    'jump_if_one:nextcolumn', # (always jumps)

    # end of construction: prepare to retract vertically
    'doneconstructing:', 
    erase,extend, # remove the dummy mark (erase includes a retract)
    # (assume came immediately after start of a new row)
    toggle_D, # close D (for good)
    toggle_C, # open C
    extend_left,extend,erase,retract_left,
    retract,retract,retract,retract_right,
    mark, # dummy mark, to allow the unconditional jump below
    'jump_if_one:retractcolumn',
    
    # done retracting vertically; sheath, trigger and retract
    'inject:',     
    erase,retract_left,
    retract,retract,
    extend_right,
    extend,
    inject_sheath,inject_trigger,
    retract,retract,
    retract_right,retract,retract,retract,
    stop
])

# --------------------------------
# now write the tapes:
# --------------------------------

# first we write the program and marker tapes (P and M)
# then we encode the whole pattern onto the data tape
# (program length is mostly unrelated to machine size, so it all works)
write_program(program)

# after writing P and M we can now define the area to be constructed
r = rect( g.getselrect() ) # select an area to copy
if r.empty: 
    r = rect( g.getrect() ) # or select nothing to copy the whole machine
else:
    # put the data tape at the top-right of the constructed area
    X = r.width + 5
    Y = r.height

oldsecs = time()

data_tape_length = 0
width = r.width
height = r.height
x = r.left
y = r.top

# we need the tape length before we can write it
# (too long to store, and we must write it backwards)
for row in inclusive_range(y+height-1,y):

    newsecs = time()
    if newsecs - oldsecs >= 1.0:     # refresh every second
        oldsecs = newsecs
        g.show('Computing tape length: '+'%.1f'%(100.0*((y+height-1)-row)/height)+'%...')
        g.update()
        g.dokey(g.getkey())

    # grab the whole row (faster than repeated calls to getcell)
    row_contents = g.getcells([x,row,width,1])
    
    # locate the right-hand edge:
    far_right = 0
    if not row_contents:
        g.exit('Empty rows forbidden: '+str(row))
    if len(row_contents)%3==0: far_right = row_contents[-3]
    else: far_right = row_contents[-4]
    # (Golly's cell lists are a bit confusing)
        
    # work along the row:
    col = x
    list_pos = 0
    while col <= far_right:
        if row_contents[list_pos]==col:
            # 11 : write a 1
            data_tape_length += 2
            col += 1
            list_pos += 3
        elif row_contents[list_pos] > col+N: # next N cells zero?
            # 01 : write N zeroes
            data_tape_length += 2
            col += N
        else:
            # 10 : write a zero
            col += 1
            data_tape_length += 2
            
    # 001 : finished the row
    data_tape_length += 3
        
# 000 : end of construction (we skip this command)

saved_tape_length = data_tape_length
data_tape_length -= 1  # (fence-posts)

# now we know how long the tape is, we can write it directly
for row in inclusive_range(y+height-1,y):

    newsecs = time()
    if newsecs - oldsecs >= 1.0:     # refresh every second
        oldsecs = newsecs
        g.show('Writing tape: '+'%.1f'%(100.0*((y+height-1)-row)/height)+'%...')
        g.update()
        g.dokey(g.getkey())

    # grab the whole row (faster than repeated calls to getcell)
    row_contents = g.getcells([x,row,width,1])
    
    # locate the right-hand edge:
    far_right = 0
    if not row_contents:
        g.exit('Empty rows forbidden: '+str(row))
    if len(row_contents)%3==0: far_right = row_contents[-3]
    else: far_right = row_contents[-4]
    # (Golly's cell lists are a bit confusing)
        
    # work along the row:
    col = x
    list_pos = 0
    while col <= far_right:
        if row_contents[list_pos]==col:
            # 11 : write a 1
            if write_tapes:
                g.setcell(data_tape_x+data_tape_length,data_tape_y,1)
                g.setcell(data_tape_x+data_tape_length-1,data_tape_y,1)
            data_tape_length -= 2
            col += 1
            list_pos += 3
        elif row_contents[list_pos] > col+N: # next N cells zero?
            # 01 : write N zeroes
            if write_tapes:
                g.setcell(data_tape_x+data_tape_length-1,data_tape_y,1)
            data_tape_length -= 2
            col += N
        else:
            # 10 : write a zero
            if write_tapes:
                g.setcell(data_tape_x+data_tape_length,data_tape_y,1)
            col += 1
            data_tape_length -= 2
            
    # 001 : finished the row
    if write_tapes:
        g.setcell(data_tape_x+data_tape_length-2,data_tape_y,1)
    data_tape_length -= 3
        
if not data_tape_length==-1:
    g.exit('Error in script: Residual tape length: {0:n}'.format(saved_tape_length))

# activate the injection receiver
#for i in range(19857,19865):
#    g.setcell(i,50,2)
#    g.setcell(i,51,1)
#    g.setcell(i,52,2)
#g.setcell(19856,51,6)
#g.setcell(19857,51,0)
