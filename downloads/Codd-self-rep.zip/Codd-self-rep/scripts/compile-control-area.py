# This tape was used during construction of Codd's machine. It lays out the
# control area for you as this would be impossible to do by hand.

from glife import rect
from time import time
import golly as g

oldsecs = time()

def allow_golly_to_update():
    global oldsecs
    newsecs = time()
    if newsecs - oldsecs >= 1.0:     # refresh every second
        oldsecs = newsecs
        g.update()
        g.dokey(g.getkey())

# http://kogs-www.informatik.uni-hamburg.de/~meine/python_tricks
def flatten(x): # flatten nested lists completely
    result = []
    for el in x:
        if hasattr(el, "__iter__") and not isinstance(el, basestring):
            result.extend(flatten(el))
        else:
            result.append(el)
    return result

# returns the sign of the number x (not quite the same as the c function)
def sgn(x):
    if x<0: return -1
    else: return 1

# range from start to stop (either direction)
#   twoway_range(0,10,2)==[0,2,4,6,8]
#   twoway_range(0,-10,2)==[0,-2,-4,-6,-8]
def twoway_range(start,stop,step=1):
    return range(start,stop,sgn(stop-start)*abs(step))

# range from start to stop including both end points (either direction)
#   inclusive_range(0,10,2)==[0,2,4,6,8,10]
#   inclusive_range(0,-10,2)==[0,-2,-4,-6,-8,-10]
def inclusive_range(start,stop,step=1):
    return twoway_range(start,stop+sgn(stop-start)*abs(step),step)

# connect horiz wires at x1,y1 with ?,y2
# (either both lists are in ascending order or both are descending)
def connect(x1,y1_list_orig,y2_list_orig):
    # take local copies of the input lists
    y1_list = y1_list_orig[:]
    y2_list = y2_list_orig[:]
    if not len(y1_list)==len(y2_list):
        raise ValueError('Lists passed to connect function must be\
same length!')
    # if y1_list is descending, we reverse both lists
    if len(y1_list)>1 and y1_list[1]<y1_list[0]:
        y1_list.reverse()
        y2_list.reverse()
    # we leave 1 cell for safe sheathing of the verticals that follow
    for i,y in enumerate(y1_list):
        g.setcell(x1,y,1)
    x = x1+1
    vert_sep = 4 # we need this much room to ensure safe sheathing
    horiz_sep = 3
    all_done = False
    while not all_done:
        allow_golly_to_update()
        all_done = True
        new_y_list = []
        # move all wires as far as possible towards the next wire or
        # the destination
        for i,y in enumerate(y1_list):
            new_y = y2_list[i]
            if i>0 and new_y<y:
                new_y = max(max(y1_list[i-1],y2_list[i-1])+vert_sep,new_y)
            elif i<len(y1_list)-1 and new_y>y:
                new_y = min(min(y1_list[i+1],y2_list[i+1])-vert_sep,new_y)
            if not new_y==y:
                all_done = False
            new_y_list.append(new_y)
        # if some wires are still moving, draw the step and prepare for the next
        if not all_done:
            for i,new_y in enumerate(new_y_list):
                for y in inclusive_range(y1_list[i],new_y):
                    g.setcell(x,y,1)
                for j in inclusive_range(1,horiz_sep):
                    g.setcell(x+j,new_y,1)
            x += horiz_sep
            y1_list = new_y_list
    return x

#connect(0,[0,-6,-12,-18,-24,-30],[100,90,80,70,60,50])
#connect(0,[0,6,12,18,24,30],[50,60,70,80,90,100])
#g.exit()

control_outputs = [ # (travel to the right)
'A','g4','g5','g6','g7','B','C','D','E','F','H','K','M','P',
'w0','w1','w2','w3','w4','w5','w6','w7','w8','w9','w10','w11','t12']
control_inputs = [ # (travel to the left)
'q11','q10','q9','q8','q7','q6','q5','q4',
'p11','p10','p9','p8','p7','p6','p5','p4',
'f15','f14','f13','f12','f11','f10','f9','f8','f7','f6','f5','f4','f3',
'f2','f1',#'f0',
'e12','e11','e10','e9','e8','e7','e6','e5','e4','e3','e2','e1','e0','s0']
internal_program_gotos = ['p8','s11','s10','s8','s7','s6','s3','s4']
# gotos, e.g. '>p8' travels to the right, until it can join p8

# these are the connections on the right we want to connect to the
# microprogram on the left:
all_inputs = []
all_inputs.extend(control_outputs)
all_inputs.extend(control_inputs)
#all_inputs.reverse()

# the total_ordering list (from bottom to top) is used during the re-ordering
# process from microprogram to all_inputs
total_ordering = all_inputs[:]
travelling_right = control_outputs[:]
travelling_left = control_inputs[:]
for a in internal_program_gotos:
    travelling_left.append(a)
    travelling_right.append('>'+a)
    if a in total_ordering:
        total_ordering.insert(total_ordering.index(a)+1,'>'+a)
    else:
        total_ordering.append(a)
        total_ordering.append('>'+a)

# g.warn('Input connections to control area: '+str(all_inputs)+\
       # '('+str(len(all_inputs))+\
       # ')\n\nOrdering used for connections: '+str(total_ordering) + \
       # '('+str(len(total_ordering))+')\n\n(from bottom to top)')

# the program is a list of pairs: the first of each pair is the program entry
# label, the second is the list of commands for that entry
# (also, s0 is a program label, >s0 means goto s0)
microprogram = [                  # From Codd (1968), page 101-2
('s0',['M','x','xr','t12','sw']),
('e12',['cs','rr','M','D','B','K','P','xr','P','x','K','B','D','P','H','w4',\
        '>s4']),
('s4',['sw']),
('e4',['cs','E']),
('p4',['>s4']),
('q4',['H','w4','rr','M','x','M','xr','P','>s3']),
('s3',['P','w0','sw']),
('e0',['cs','rr','M','x','M','xr','w0','w1','sw']),
('e1',['cs','rr','M','x','M','xr','w1','w2','sw']),
('e2',['cs','rr','M','x','M','xr','w2','w3','sw']),
('e3',['cs','rr','M','x','M','xr','w3','P','F']),
# 'f0' (stop) we skip because we don't want to connect it to anything
('f1',['C','>s3']),
('f2',['D','>s3']),
('f3',['>s3']),
('f4',['B','x','B','>s3']),
('f5',['B','xl','B','>s3']),
('f6',['B','xr','B','>s3']),
('f7',['B','r','B','>s3']),
('f8',['B','rl','B','>s3']),
('f9',['B','rr','B','>s3']),
('f10',['B','m','B','>s3']),
('f11',['B','e','B','>s3']),
('f12',['H','w5','B','sw']),
('e5',['cs','B','E']),
('p5',['w5','w6','P','>s6']),
('s6',['sw']),
('e6',['cs','E']),
('p6',['w6','rr','M','x','M','xr','P','H','>s3']),
('q6',['rr','M','x','M','xr','>s6']),
('q5',['w5','w7','P','>s7']),
('s7',['sw']),
('e7',['cs','E']),
('p7',['w7','rr','M','r','P','xr','w8','>s8']),
('q7',['P','K','r','rr','x','xr','x','m','K','P','rr','M','x','M','xr','>s7']),
('s8',['sw']),
('e8',['cs','E']),
('p8',['rr','P','r','P','xr','>s8']),
('q8',['w8','rr','r','xr','w9','sw']),
('e9',['cs','rr','x','xr','E']),
('p9',['w9','w8','>p8']), # (looks odd but correct)
('q9',['w9','M','>s10']),
('s10',['w10','K','sw']),
('e10',['cs','E']),
('p10',['K','w10','H','M','rr','M','P','xr','P','>s3']),
('q10',['e','rr','r','xr','x','K','w10','w11','M','>s11']),
('s11',['rr','P','x','P','xr','sw']),
('e11',['cs','E']),
('p11',['>s11']),
('q11',['w11','M','>s10']),
('f13',['>s3']),
('f14',['B','i','B','>s3']),
('f15',['B','j','B','>s3'])
]

# the microcommands are expanded into gate channels using this dictionary:
commands = {                          # From Codd (1968), Table 6.2, page 96
'G4':['g4','A','g4'], # send '40' signal to the tapes
'G5':['g5','A','g5'], #  (open gate g4, open gate A, then close g4)
'G6':['g6','A','g6'], #  (A closes itself after a signal goes through)
'G7':['g7','A','g7'],
'x':['G7','G6'],                     # extend
'xl':['G4','G4','G5','G6'],          # extend left
'xr':['G5','G5','G4','G6'],          # extend right
'r':['G4','G5','G6','G6'],           # retract
'rl':['G5','G6','G6','G6'],          # retract left
'rr':['G4','G6','G6','G6'],          # retract right
'm':['G7','G6','G4','G5','G7','G6'], # mark if zero
'e':['G6','G7','G4','G5','G6','G6'], # erase if one
'sw':['G7','G7'],                    # sense and wait
'cs':['G4','G6'],                    # cap after sense
'i':['G7','G5','G6'],                # inject signal 06
'j':['G6','G7','G7','G6','G6']       # inject signal 07
}

def expand_commands(s):
    if s in commands:
       return commands[s] # expand the command
    else:
       return s # this command is an output/entry, can use directly

# A simple font, from Golly's pop-plot.pl (thanks to Andrew)
font = {
' ':'',
'!':'2bo$2bo$2bo$2bo$2bo2$2bo!',
'"':'bobo$bobo$bobo!',
'#':'bobo$bobo$5o$bobo$5o$bobo$bobo!',
'$':'b3o$obobo$obo$b3o$2bobo$obobo$b3o!',
'%':'2o2bo$2o2bo$3bo$2bo$bo$o2b2o$o2b2o!',
'&':'b2o$o2bo$o2bo$b2o$o2bo$o2bo$b2obo!',
'\'':'2bo$2bo$2bo!',
'(':'3bo$2bo$2bo$2bo$2bo$2bo$3bo!',
')':'bo$2bo$2bo$2bo$2bo$2bo$bo!',
'*':'$obobo$b3o$5o$b3o$obobo!',
'+':'$2bo$2bo$5o$2bo$2bo!',
',':'6$2bo$2bo$bo!',
'-':'3$5o!',
'.':'6$2bo!',
'/':'3bo$3bo$2bo$2bo$2bo$bo$bo!',
'0':'b3o$o3bo$o2b2o$obobo$2o2bo$o3bo$b3o!',
'1':'2bo$b2o$2bo$2bo$2bo$2bo$b3o!',
'2':'b3o$o3bo$4bo$3bo$2bo$bo$5o!',
'3':'b3o$o3bo$4bo$2b2o$4bo$o3bo$b3o!',
'4':'3bo$2b2o$bobo$o2bo$5o$3bo$3bo!',
'5':'5o$o$o$b3o$4bo$o3bo$b3o!',
'6':'b3o$o$o$4o$o3bo$o3bo$b3o!',
'7':'5o$4bo$3bo$2bo$bo$o$o!',
'8':'b3o$o3bo$o3bo$b3o$o3bo$o3bo$b3o!',
'9':'b3o$o3bo$o3bo$b4o$4bo$4bo$b3o!',
':':'2$2bo4$2bo!',
';':'2$2bo4$2bo$2bo$bo!',
'<':'$3bo$2bo$bo$2bo$3bo!',
'=':'2$5o2$5o!',
'>':'$bo$2bo$3bo$2bo$bo!',
'?':'b3o$o3bo$4bo$2b2o$2bo2$2bo!',
'@':'b3o$o3bo$ob3o$obobo$ob2o$o$b3o!',
'A':'b3o$o3bo$o3bo$5o$o3bo$o3bo$o3bo!',
'B':'4o$o3bo$o3bo$4o$o3bo$o3bo$4o!',
'C':'b3o$o3bo$o$o$o$o3bo$b3o!',
'D':'4o$o3bo$o3bo$o3bo$o3bo$o3bo$4o!',
'E':'5o$o$o$3o$o$o$5o!',
'F':'5o$o$o$3o$o$o$o!',
'G':'b3o$o3bo$o$o2b2o$o3bo$o3bo$b3o!',
'H':'o3bo$o3bo$o3bo$5o$o3bo$o3bo$o3bo!',
'I':'b3o$2bo$2bo$2bo$2bo$2bo$b3o!',
'J':'2b3o$3bo$3bo$3bo$3bo$o2bo$b2o!',
'K':'o3bo$o2bo$obo$2o$obo$o2bo$o3bo!',
'L':'o$o$o$o$o$o$5o!',
'M':'o3bo$2ob2o$obobo$obobo$o3bo$o3bo$o3bo!',
'N':'o3bo$2o2bo$obobo$o2b2o$o3bo$o3bo$o3bo!',
'O':'b3o$o3bo$o3bo$o3bo$o3bo$o3bo$b3o!',
'P':'4o$o3bo$o3bo$4o$o$o$o!',
'Q':'b3o$o3bo$o3bo$o3bo$obobo$o2bo$b2obo!',
'R':'4o$o3bo$o3bo$4o$o2bo$o3bo$o3bo!',
'S':'b3o$o3bo$o$b3o$4bo$o3bo$b3o!',
'T':'5o$2bo$2bo$2bo$2bo$2bo$2bo!',
'U':'o3bo$o3bo$o3bo$o3bo$o3bo$o3bo$b3o!',
'V':'o3bo$o3bo$o3bo$o3bo$o3bo$bobo$2bo!',
'W':'o3bo$o3bo$o3bo$obobo$obobo$2ob2o$o3bo!',
'X':'o3bo$o3bo$bobo$2bo$bobo$o3bo$o3bo!',
'Y':'o3bo$o3bo$bobo$2bo$2bo$2bo$2bo!',
'Z':'5o$4bo$3bo$2bo$bo$o$5o!',
'[':'2b2o$2bo$2bo$2bo$2bo$2bo$2b2o!',
'\\':'bo$bo$2bo$2bo$2bo$3bo$3bo!',
']':'b2o$2bo$2bo$2bo$2bo$2bo$b2o!',
'^':'2bo$bobo$o3bo!',
'_':'6$5o!',
'`':'o$bo!',
'a':'2$b4o$o3bo$o3bo$o3bo$b4o!',
'b':'o$o$4o$o3bo$o3bo$o3bo$4o!',
'c':'2$b4o$o$o$o$b4o!',
'd':'4bo$4bo$b4o$o3bo$o3bo$o3bo$b4o!',
'e':'2$b3o$o3bo$5o$o$b4o!',
'f':'2b2o$bo2bo$bo$3o$bo$bo$bo!',
'g':'2$b3o$o3bo$o3bo$o3bo$b4o$4bo$b3o!',
'h':'o$o$ob2o$2o2bo$o3bo$o3bo$o3bo!',
'i':'$2bo2$2bo$2bo$2bo$2b2o!',
'j':'$3bo2$3bo$3bo$3bo$3bo$o2bo$b2o!',
'k':'o$o$o2bo$obo$3o$o2bo$o3bo!',
'l':'b2o$2bo$2bo$2bo$2bo$2bo$2b2o!',
'm':'2$bobo$obobo$obobo$o3bo$o3bo!',
'n':'2$4o$o3bo$o3bo$o3bo$o3bo!',
'o':'2$b3o$o3bo$o3bo$o3bo$b3o!',
'p':'2$4o$o3bo$o3bo$o3bo$4o$o$o!',
'q':'2$b4o$o3bo$o3bo$o3bo$b4o$4bo$4bo!',
'r':'2$ob2o$2o2bo$o$o$o!',
's':'2$b4o$o$b3o$4bo$4o!',
't':'$2bo$5o$2bo$2bo$2bo$3b2o!',
'u':'2$o3bo$o3bo$o3bo$o3bo$b4o!',
'v':'2$o3bo$o3bo$o3bo$bobo$2bo!',
'w':'2$o3bo$o3bo$obobo$2ob2o$o3bo!',
'x':'2$o3bo$bobo$2bo$bobo$o3bo!',
'y':'2$o3bo$o3bo$o3bo$o3bo$b4o$4bo$b3o!',
'z':'2$5o$3bo$2bo$bo$5o!',
'{':'3bo$2bo$2bo$bo$2bo$2bo$3bo!',
'|':'2bo$2bo$2bo$2bo$2bo$2bo$2bo!',
'}':'bo$2bo$2bo$3bo$2bo$2bo$bo!',
'~':'2$bo$obobo$3bo!'
}

# we apply the dictionary twice to expand all commands fully
all_commands = flatten(map(expand_commands,flatten(map(expand_commands,
flatten(microprogram)))))

#g.warn(str(len(all_commands))+' commands when expanded')

path_components = {
'rdcrossover': # a right wire crosses a down wire
g.parse('25bo$25bo$25bo$25bo$25bo$18b8o$18bo24b5o$18bo24bo3bo$18bo3bo20bo3bo$\
18bo3b6o15bo3bo$18bo3bo4bo15bo3bo$18bo3bo4bo15bo3bo$18bo3bo4bo15bo3bo$\
18bo3bo2b3o15bo3bo$18bo3bo12b5o3bo3bo$18bo3bo12bo3bo3bo3bo$b13o4bo3bo\
12bo3bo3bo3bo$bo11bo4b18o3bo3bo3bo$bo11bo18bo6bo3bo3bo$bo11bo18bo6b5o\
3bo$bo3b5o3bo6b5o7bo14bo$bo3bo3bo3b4o3bo3bo3b5o14bo$bo3bo3bo6bo3bo3bo\
3bo3bo5b5o4bo$bo3bo10bo3bo7bo3bo5bo3bo4bo$bo3bo10bo3bo7bo3bo5bo3bo4bo$\
2o3b8o3bo2b10o3bo5bo8b4o$bo3bo6bo3bo11bo3bo5bo$bo3bo6bo3bo11bo3bo5b7o$\
bo10bo3bo11bo3bo5bo5bo4bo$bo10bo3b13o3bo5bo5bo4bo$b12o19bo11bo4bo$4bo\
7bo19bo11bo4bo$4bo7bo19bo3b14o$4bo7b18o2bo3bo12bo$4bo11bo15bo3bo12bo$\
4bo11bo15bo3bo12bo$4b10o2bo15bo3b11o2bo$4bo7bo3b14o2bo3bo7bo4bo$4bo7bo\
16bo2bo3bo7bo4bo$4bo3bo3bo16bo2b5o3bo3bo4bo$4bo3bo3bo16bo2bo3bo3bo3bo\
4bo$4bo3b5o3b14o2bo3bo3b5o4bo$4bo11bo15bo3bo12bo$4bo11bo15bo3bo12bo$4b\
o11bo15bo3bo12bo$4b13o8b8o3b14o$25bo$25bo$25bo$25bo$25bo!'),
'lucrossover': # a left wire crosses an up wire
g.parse('25bo$25bo$25bo$25bo$25bo$b14o3b8o8b13o$bo12bo3bo15bo11bo$bo12bo3bo15bo\
11bo$bo12bo3bo15bo11bo$bo4b5o3bo3bo2b14o3b5o3bo$bo4bo3bo3bo3bo2bo16bo\
3bo3bo$bo4bo3bo3b5o2bo16bo3bo3bo$bo4bo7bo3bo2bo16bo7bo$bo4bo7bo3bo2b\
14o3bo7bo$bo2b11o3bo15bo2b10o$bo12bo3bo15bo11bo$bo12bo3bo15bo11bo$bo\
12bo3bo2b18o7bo$b14o3bo19bo7bo$bo4bo11bo19bo7bo$bo4bo11bo19b12o$bo4bo\
5bo5bo3b13o3bo10bo$bo4bo5bo5bo3bo11bo3bo10bo$6b7o5bo3bo11bo3bo6bo3bo$\
12bo5bo3bo11bo3bo6bo3bo$4o8bo5bo3b10o2bo3b8o3b2o$3bo4bo3bo5bo3bo7bo3bo\
10bo3bo$3bo4bo3bo5bo3bo7bo3bo10bo3bo$3bo4b5o5bo3bo3bo3bo3bo6bo3bo3bo$\
3bo14b5o3bo3bo3b4o3bo3bo3bo$3bo14bo7b5o6bo3b5o3bo$3bo3b5o6bo18bo11bo$\
3bo3bo3bo6bo18bo11bo$3bo3bo3bo3b18o4bo11bo$3bo3bo3bo3bo12bo3bo4b13o$3b\
o3bo3bo3bo12bo3bo$3bo3bo3b5o12bo3bo$3bo3bo15b3o2bo3bo$3bo3bo15bo4bo3bo\
$3bo3bo15bo4bo3bo$3bo3bo15bo4bo3bo$3bo3bo15b6o3bo$3bo3bo20bo3bo$3bo3bo\
24bo$3b5o24bo$25b8o$25bo$25bo$25bo$25bo$25bo!'),
'ldcrossover': # a left wire crosses a down wire
g.parse('25bo$20b15o$20bo13bo$20bo13bo$5b16o13bo$5bo8bo5bo2b8o3bo$5bo8bo5bo4bo\
4bo3bo$5bo8bo5bo4bo4bo3bo$5bo3b3o2bo5bo4bo4bo3bo$5bo3bo4bo5bo4bo2b3o3b\
o$5bo3bo4bo5bo4bo8bo$5bo3bo4bo5bo4bo8bo$5bo3b6o2b9o8bo$5bo8bo2bo11b6o$\
5bo11bo11bo$5bo11bo11bo$5b5o3b5o3b9o$9bo3bo3bo3bo$9bo3bo3bo3bo11b13o$\
9bo3bo3bo3bo3bo7bo11bo$9bo3bo3bo3bo3b6o2bo11bo$9bo3bo3bo3bo3bo4bo2bo\
11bo$9bo3bo3bo3bo3bo4bo2b10o2bo$9bo3bo3bo3bo3bo4bo2bo7bo3bo$9bo3bo3bo\
3bo3bo2b3o2bo7bo3bo$6o3bo3bo3bo3bo3bo7bo3bo3bo3b6o$5bo3bo3bo3bo3bo3bo\
7bo3bo3bo$5bo3bo3bo3bo3bo3bo7bo3b5o$5bo3bo3bo3bo3b9o3bo$5bo3b5o3bo11bo\
3bo$5bo23bo3bo$5bo23bo3bo$5b29o$11bo21bo$11bo21bo$11bo21b4o$5b14o17bo$\
5bo8bo3bo17bo$5bo8bo3bo2b8o7bo$5bo8bo3bo4bo4bo2b6o$5bo3b3o2bo3bo4bo4bo\
2bo$5bo3bo4bo3bo4bo4bo2bo$5bo3bo4bo3bo4bo2b3o2bo$5bo3bo4bo3bo4bo7b14o$\
5bo3b6o3b6o20bo$5bo8bo3bo25bo$5bo8bo3bo25bo$5bo12bo6b20o$5bo12bo6bo$5b\
18o2bo$25bo!'),
'rucrossover': # a right wire crosses an up wire
g.parse('25bo$25bo2b18o$25bo6bo12bo$6b20o6bo12bo$6bo25bo3bo8bo$6bo25bo3bo8bo$6b\
o20b6o3b6o3bo$6b14o7bo4bo3bo4bo3bo$19bo2b3o2bo4bo3bo4bo3bo$19bo2bo4bo\
4bo3bo4bo3bo$19bo2bo4bo4bo3bo2b3o3bo$14b6o2bo4bo4bo3bo8bo$14bo7b8o2bo\
3bo8bo$14bo17bo3bo8bo$14bo17b14o$14b4o21bo$17bo21bo$17bo21bo$17b29o$\
17bo3bo23bo$17bo3bo23bo$17bo3bo11bo3b5o3bo$17bo3b9o3bo3bo3bo3bo$9b5o3b\
o7bo3bo3bo3bo3bo3bo$9bo3bo3bo7bo3bo3bo3bo3bo3bo$6o3bo3bo3bo7bo3bo3bo3b\
o3bo3b6o$5bo3bo7bo2b3o2bo3bo3bo3bo3bo$5bo3bo7bo2bo4bo3bo3bo3bo3bo$5bo\
2b10o2bo4bo3bo3bo3bo3bo$5bo11bo2bo4bo3bo3bo3bo3bo$5bo11bo2b6o3bo3bo3bo\
3bo$5bo11bo7bo3bo3bo3bo3bo$5b13o11bo3bo3bo3bo$29bo3bo3bo3bo$21b9o3b5o\
3b5o$21bo11bo11bo$21bo11bo11bo$16b6o11bo2bo8bo$16bo8b9o2b6o3bo$16bo8bo\
4bo5bo4bo3bo$16bo8bo4bo5bo4bo3bo$16bo3b3o2bo4bo5bo4bo3bo$16bo3bo4bo4bo\
5bo2b3o3bo$16bo3bo4bo4bo5bo8bo$16bo3bo4bo4bo5bo8bo$16bo3b8o2bo5bo8bo$\
16bo13b16o$16bo13bo$16bo13bo$16b15o$25bo!'),
'merge_with_down': # 51x51
g.parse('25bo$25bo$25bo$25bo$25bo$25bo$25bo$18b8o$18bo$18bo$18bo3bo$18bo3b6o$\
18bo3bo4bo$18bo3bo4bo$18bo3bo4bo$18bo3bo2b3o$18bo3bo$18bo3bo$18bo3bo$\
18b8o$25bo$25bo$25bo$13b5o7bo$13bo3bo7bo$10o3bo3bo3b5o$9bo3bo7bo3bo$9b\
o3bo7bo3bo$9bo2b10o3bo$9bo11bo3bo$9bo11bo3bo$9bo11bo3bo$9b13o3bo$25bo$\
25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$\
25bo$25bo$25bo!'),
'merge_with_up': # 51x51
g.parse('25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$\
25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$13b5o7bo$13bo3bo7bo$10o3b\
o3bo3b5o$9bo3bo7bo3bo$9bo3bo7bo3bo$9bo2b10o3bo$9bo11bo3bo$9bo11bo3bo$\
9bo11bo3bo$9b13o3b8o$28bo3bo$28bo3bo$28bo3bo$23b3o2bo3bo$23bo4bo3bo$\
23bo4bo3bo$23bo4bo3bo$23b6o3bo$28bo3bo$32bo$32bo$25b8o$25bo$25bo$25bo$\
25bo$25bo$25bo!'),
'top_of_merge': # 51x51
g.parse('25$26o$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25b\
o$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo!'),
'bottom_of_merge': # 51x51
g.parse('25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$\
25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25bo$25b26o!'),
'pass_through': # 51x18 (line at y=15)
g.parse('14$51o!'),
'command_entry': # 3x52
g.parse('3o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o\
$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$3o!'),
'command_delay_right': # 8x52
g.parse('5b3o$5bo$5bo$5bo$5bo$5bo$6o3$6o$5bo$5bo$6o3$6o$5bo$5bo$6o3$6o$5bo$5bo$\
6o3$6o$5bo$5bo$6o3$6o$5bo$5bo$6o3$6o$5bo$5bo$6o3$6o$5bo$5bo$6o3$8o!'),
'command_delay_middle': # 10x46
g.parse('10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$10o3$\
10o3$10o!'),
'command_delay_left': # 6x46
g.parse('6o$o$o$6o3$6o$o$o$6o3$6o$o$o$6o3$6o$o$o$6o3$6o$o$o$6o3$6o$o$o$6o3$6o$o\
$o$6o3$6o$o$o$6o!'),
}

# write the supplied text s from the position x,y at its bottom-left
def write(s,x,y):
    letterspacing = 7
    for c in s:
        g.putcells(g.parse(font[c]),x,y-8)
        x = x + letterspacing

# draw the components, for testing purposes
#for i,c in enumerate(path_components):
#    g.putcells(g.parse(path_components[c]),i*100,0)
#g.exit()

start_x = 0
start_y = 0
component_width = 51 # components are square, so same whichever orientation
linespacing = 51 # we need this much for compact(-ish!) delay lines
# (it also matches component_width, for easier wiring on the first column)

draw_labels = True
labelwidth = 30

y_list = map(lambda i:start_y - i*linespacing,range(len(all_commands)))
x = start_x

# draw the delay lines
n_delay_units = 10 # 150 (slow to draw them all)
y = start_y
g.show('Drawing delay lines...')
for i,command in enumerate(all_commands):
    allow_golly_to_update()
    if command in travelling_left:
        g.putcells(path_components['command_entry'],x-3,y-52+1)
    elif i<len(all_commands)-1 and not all_commands[i+1] in travelling_left:
        g.putcells(path_components['command_delay_right'],x-8,y-52+1)
        for n in range(n_delay_units):
            g.putcells(path_components['command_delay_middle'],\
                x-8-10*(n+1),y-46+1)
        g.putcells(path_components['command_delay_left'],\
            x-8-10*n_delay_units,y-46+1)
    y -= linespacing
    
#g.show('')
#g.exit() # DEBUG

# now draw the main control area
# (N.B. we enforce that merging always ends at the bottom, not in the middle or the top)
columns = 0
reducing_phase = False # it's neater and almost as efficient without
reordering_phase = True
while True:
    g.show('Drawing column '+str(columns+1)+'...')

    if reducing_phase:
        # merge the most common command
        command_counts = map(all_commands.count,total_ordering)
        max_freq = max(command_counts)
        if max_freq>1:
            command_to_merge = total_ordering[command_counts.index(max_freq)]
            # decide the index of the command in the output column
            index_of_merged_command = columns # just stack at the bottom
        else:
            reducing_phase = False # just need to reorder and we're done
            reordering_phase = True

    if reordering_phase:
        # search for the lowest entry that is misplaced
        need_reorder = False
        for i,command in enumerate(total_ordering):
            if not all_commands[i] == command or all_commands.count(command)>1:
                need_reorder = True
                command_to_merge = command
                index_of_merged_command = i
                break
        if not need_reorder:
            break # we're completely finished

    # decide which commands need which structures
    if not command_to_merge in all_commands:
        raise RuntimeError('Command "'+command_to_merge+'" not found \
in all_commands!?')
    first_instance = min(index_of_merged_command,\
      all_commands.index(command_to_merge))
    last_instance = max(index_of_merged_command,len(all_commands)-1 - \
      all_commands[::-1].index(command_to_merge))
    actions = ['']*len(all_commands)
    new_all_commands = []
    outgoing_index_of_merged = index_of_merged_command
    for i,command in enumerate(all_commands):
        if i<first_instance or i>last_instance:
            actions[i] = 'pass_through'
            new_all_commands.append(command)
        elif command==command_to_merge:
            if not command in all_commands[i+1:]:
                actions[i] = 'top_of_merge'
            elif command in travelling_left:
                actions[i] = 'merge_with_up'
            else:
                actions[i] = 'merge_with_down'
        else:
            if command_to_merge in travelling_left:
                if command in travelling_right:
                    actions[i] = 'rucrossover'
                else:
                    actions[i] = 'lucrossover'
            else:
                if command in travelling_right:
                    actions[i] = 'rdcrossover'
                else:
                    actions[i] = 'ldcrossover'
            new_all_commands.append(command)
    actions.insert(index_of_merged_command,'bottom_of_merge')
    #g.warn(command_to_merge+':\n\n'+str(all_commands) +'\n\n'+str(actions))
    new_all_commands.insert(outgoing_index_of_merged,command_to_merge)
    # g.warn('before column:\n\n'+str(all_commands) +'('\
        #+str(len(all_commands))+\
        # ')\n\nafter:\n\n'+str(new_all_commands)+'\
        #('+str(len(new_all_commands))+')')
    # lay out the new column
    input_y_list = []
    output_y_list = []
    components = []
    y = start_y
    for i,action in enumerate(actions):
        if action=='pass_through':
            y -= 51 # 18 (realised lated compacting them doesn't help)
            d = 14
            input_y_list.append(y+d)
            output_y_list.append(y+d)
        else:
            y -= 51
            d = 25
            if not action=='bottom_of_merge':
                # (this structure doesn't have a left-side input)
                input_y_list.append(y+d)
            if not (action=='merge_with_up' or action=='merge_with_down'\
                    or action=='top_of_merge'):
                # (these structures don't have a right-side output)
                output_y_list.append(y+d)
        components.append([action,y])
    # draw the connections from the previous column
    x = connect(x,y_list,input_y_list)
    # draw the column input labels
    if draw_labels:
        for i,y in enumerate(input_y_list):
            for lx in range(x,x+labelwidth): g.setcell(lx,y,1)
            write(all_commands[i],x+2,y-3)
        x += labelwidth
    # draw the components
    for c in components:
        allow_golly_to_update()
        g.putcells(path_components[c[0]],x,c[1])
    x += component_width
    # draw the column output labels
    if draw_labels:
        for i,y in enumerate(output_y_list):
            for lx in range(x,x+labelwidth): g.setcell(lx,y,1)
            write(new_all_commands[i],x+2,y-3)
        x += labelwidth
    # prepare for the next column
    all_commands = new_all_commands
    y_list = output_y_list
    columns += 1

# make the final neat column
final_spacing = component_width # since we will need more crossovers
output_y_list = map(lambda i:start_y-i*final_spacing,range(len(all_commands)))
x = connect(x,y_list,output_y_list)
# draw the column output labels
if draw_labels:
    for i,y in enumerate(output_y_list):
        for lx in range(x,x+labelwidth): g.setcell(lx,y,1)
        write(new_all_commands[i],x+2,y-3)
    x += labelwidth

g.show('')

g.warn(str(columns)+' columns written.')

g.warn('Input connections to control area: '+str(all_inputs)+\
       '('+str(len(all_inputs))+\
       ')\n\nOrdering used for connections: '+str(total_ordering) + \
       '('+str(len(total_ordering))+')\n\n(from bottom to top)')

