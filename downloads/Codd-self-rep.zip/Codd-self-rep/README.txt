First download Golly:
http://golly.sourceforge.net

The rule table for Codd2 is supplied with Golly 2.1 or later (see Rules/Codd2.rule).

Patterns included:

Codd-small-demo.mc.gz is ready to run, and just constructs a small structure.
It takes 8.9E+11 (890 billion) timesteps to complete.

Codd-self-rep.mc.gz is ready to run, and contains the full tape for self-replication.
(Please note that this has not been fully tested - current estimates are that it will
take at least 1.7E+18 timesteps or approximately 1000 years to complete.)
 
Codd-body.mc.gz contains the unsheathed body of the machine.

Scripts included: (read them for more information)

make-Codd-tape.py: makes the program and data tapes for construction and self-rep.
Load Codd-body.mc.gz and then draw and select a small pattern and run this script.
Ensure that the pattern has a plus shape (the injection receiver) in its lower-left
corner as in Codd-body.mc.gz, else the machine may go wrong.

compile-control-area.py: was used during the implementation of Codd's machine,
as drawing it all by hand would have taken too long.

monitor_gates.py: writes a log of the gates changing, useful for debugging.

For more details, see the paper:

Tim J. Hutton (2010) "Codd's self-replicating computer" Artificial Life.
PDF: http://www.sq3.org.uk/papers/Hutton_CoddsSelfReplicatingComputer_2010.pdf
tim.hutton@gmail.com, http://www.sq3.org.uk
