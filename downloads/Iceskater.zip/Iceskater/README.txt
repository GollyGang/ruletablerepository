Iceskater CA for Golly

by Jordan Goldstein

IMPORTANT: Patterns that have more than one skater or that use the CA
in any unintended way are not supported.

HOW IT WORKS:

Imagine the following situation. You stand on an infinitely large grid.
Everywhere you walk, ice materializes on the ground.

You start walking forward along one of lines on the grid. Every time
you walk forward a meter, you turn right 90 degrees. You continue this
process of turn, walk, turn, walk.

However, if a line you walk upon happens to be covered with ice,
you slip across the ice, then walk a meter, THEN turn and continue.

This system is being simulated in the Iceskater CA.


STATES:

State 0: Empty state.
State 1: Represents a corner on the grid.
State 2: Represents an edge between two corners on the grid.
State 3: Represents the skater facing up.
State 4: Represents the skater facing right.
State 5: Represents the skater facing down.
State 6: Represents the skater facing left.

Excited skaters are ones that have just walked onto an empty edge
and are about to make a turn.

State 7: Represents the excited skater facing up.
State 8: Represents the excited skater facing right.
State 9: Represents the excited skater facing down.
State 10: Represents the excited skater facing left.
