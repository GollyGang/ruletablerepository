# This script creates a specified TriLife-Bnnn...Snnn... rule
# representing a totalistic CA on a triangular grid, where each
# triangle has 12 neighboring triangles.
# 
# Inspired by the work of Carter Bays and his students (see the
# applet at http://www.cse.sc.edu/~bays/trilife3/home.html).
# Note that the applet's rules list survivals before births,
# so 4,5,6/4 is equivalent to TriLife-B4S456.
# 
# The simplest way to emulate a triangular grid on a square grid is
# to split each square with a diagonal line, so each cell contains
# 2 triangles.  This means we need 4 states to emulate a 2-state
# triangular CA:
# 
#     0        1        2        3
#   ------   ------   ------   ------
#   |\   |   |\   |   |\***|   |\***|
#   | \  |   |*\  |   | \**|   |*\**|
#   |  \ |   |**\ |   |  \*|   |**\*|
#   |   \|   |***\|   |   \|   |***\|
#   ------   ------   ------   ------
# 
# Author: Andrew Trevorrow (andrew@trevorrow.com), Nov 2009.

import golly

# check if we can create a .rule file (ie. Golly 2.5+)
try:
    from glife.RuleTree import ConvertTreeToRule
    create_rule_file = True
except:
    create_rule_file = False

try:
    set
except NameError:
    # Python versions < 2.4 don't have "set" built-in
    from sets import Set as set

rulespec = golly.getstring('''\
This script will create a specified TriLife-* rule.
Enter the rule's suffix as Bn...Sn... where the allowed
digits are 0123456789abc (but 0 is not valid after B).

For example, B4S456 means a birth occurs if an empty
triangle has exactly 4 live neighbors, and an existing
triangle survives only if it has 4, 5 or 6 live neighbors:''',
"B4S456", "Enter a TriLife rule")

# do error checking
if len(rulespec) == 0: golly.exit("No rule specified.")
if rulespec[0] != 'B': golly.exit("B is missing.")
bdigits =     ['1','2','3','4','5','6','7','8','9','a','b','c']
sdigits = ['0','1','2','3','4','5','6','7','8','9','a','b','c']
bset = set([])
sset = set([])
try:
    bnums, snums = rulespec.split('S')
except:
    golly.exit("S is missing.")
bnums = bnums.replace('B','')
for ch in bnums:
    if ch in bdigits:
        if ch > '9':
            bset.add(10 + ord(ch) - ord('a'))
        else:
            bset.add(int(ch))
    else:
        golly.exit("Illegal digit after B: " + ch + " (must be 123456789abc).")
for ch in snums:
    if ch in sdigits:
        if ch > '9':
            sset.add(10 + ord(ch) - ord('a'))
        else:
            sset.add(int(ch))
    else:
        golly.exit("Illegal digit after S: " + ch + " (must be 0123456789abc).")

# convert to canonical rule
canonrule = 'B'
for ch in bdigits:
    if ch > '9':
        if (10 + ord(ch) - ord('a')) in bset: canonrule += ch
    elif int(ch) in bset:
        canonrule += ch
canonrule += 'S'
for ch in sdigits:
    if ch > '9':
        if (10 + ord(ch) - ord('a')) in sset: canonrule += ch
    elif int(ch) in sset:
        canonrule += ch

prefix = "TriLife"
name = prefix + '-' + canonrule

n_states = 4
n_neighbors = 8

def transition_function(s):
    # s[0..8] are cell states in the order NW, NE, SW, SE, N, W, E, S, C
    NW, NE, SW, SE, N, W, E, S, C = s
    
    # count the number of live neighbors for the left and right triangles
    # in the central cell (each triangle has 12 neighbors)
    Lnc = 0
    Rnc = 0
   
    if NW == 1 or NW == 2:
        Lnc += 1
        Rnc += 1
    elif NW == 3:
        Lnc += 2
        Rnc += 2
   
    if SE == 1 or SE == 2:
        Lnc += 1
        Rnc += 1
    elif SE == 3:
        Lnc += 2
        Rnc += 2
   
    if SW == 2 or SW == 3: Lnc += 1
    if NE == 1 or NE == 3: Rnc += 1
    
    if N == 1 or N == 3: Lnc += 1
    if E == 1 or E == 3: Lnc += 1
    
    if S == 2 or S == 3: Rnc += 1
    if W == 2 or W == 3: Rnc += 1
   
    if W == 1 or W == 2:
        Lnc += 1
    elif W == 3:
        Lnc += 2
    if S == 1 or S == 2:
        Lnc += 1
    elif S == 3:
        Lnc += 2
   
    if N == 1 or N == 2:
        Rnc += 1
    elif N == 3:
        Rnc += 2
    if E == 1 or E == 2:
        Rnc += 1
    elif E == 3:
        Rnc += 2
   
    if C == 0:
        # both triangles are dead, so check for birth(s)
        if Lnc in bset and Rnc in bset: return 3
        if Rnc in bset: return 2
        if Lnc in bset: return 1
        return 0
    elif C == 1:
        # left triangle is alive, right is dead
        Rnc += 1
        if Rnc in bset:
            if Lnc in sset:
                return 3
            else:
                return 2
        else:
            if Lnc in sset:
                return 1
            else:
                return 0
    elif C == 2:
        # left triangle is dead, right is alive
        Lnc += 1
        if Lnc in bset:
            if Rnc in sset:
                return 3
            else:
                return 1
        else:
            if Rnc in sset:
                return 2
            else:
                return 0
    else:
        # C == 3, ie. both triangles are alive, so check if they survive
        Lnc += 1
        Rnc += 1
        if Lnc in sset and Rnc in sset: return 3
        if Rnc in sset: return 2
        if Lnc in sset: return 1
        return 0

class GenerateRuleTree:

    def __init__(self,numStates,numNeighbors,transFunc):
        self.numParams = numNeighbors + 1
        self.world = {}
        self.r = []
        self.params = [0]*self.numParams
        self.nodeSeq = 0
        self.numStates = numStates
        self.numNeighbors = numNeighbors
        self.transFunc = transFunc
        self.recur(self.numParams)

    def getNode(self,n):
        if n in self.world:
            return self.world[n]
        else:
            new_node = self.nodeSeq
            self.nodeSeq += 1
            self.r.append(n)
            self.world[n] = new_node
            return new_node

    def recur(self,at):
        if at == 0:
            return self.transFunc(self.params)
        n = str(at)
        for i in xrange(self.numStates):
            # report progress
            if at == self.numParams:
                golly.show('Generating rule tree: '+str(int(100*i/self.numStates))+'%...')
            if at == self.numParams-1:
                # allow keyboard interaction and let user cancel script
                golly.dokey(golly.getkey())
            self.params[self.numParams-at] = i
            n += " " + str(self.recur(at-1))
        return self.getNode(n)

    def writeRuleTree(self,name):
        # create a .tree file in user's rules directory
        f=open(golly.getdir("rules") + name + ".tree", 'w')
        f.write("# automatically generated by TriLife-gen.py\n")
        f.write("num_states=" + str(self.numStates)+"\n")
        f.write("num_neighbors=" + str(self.numNeighbors)+"\n")
        f.write("num_nodes=" + str(len(self.r))+"\n")
        for rule in self.r:
            f.write(rule+"\n")
        f.flush()    # ensure file is complete (only needed on Windows?)
        f.close()

gen = GenerateRuleTree(n_states, n_neighbors, transition_function)
gen.writeRuleTree(name)

golly.new(name + " demo")
if create_rule_file:
    # we're running in Golly 2.5+
    rulepath = golly.getdir("rules") + name + ".rule"
    
    # use name.tree to create name.rule or update tree data in existing name.rule
    # (also deletes name.tree)
    ConvertTreeToRule(name, n_states, [])
    
    golly.setalgo("RuleLoader")
    golly.setrule(name)
    golly.select([0,0,60,40])
    golly.randfill(50)
    golly.fit()
    golly.select([])
    golly.show("Created " + rulepath)
else:
    golly.setalgo("RuleTree")   # in case name.table exists
    golly.setrule(name)
    golly.select([0,0,60,40])
    golly.randfill(50)
    golly.fit()
    golly.select([])
    golly.show("Created " + name + ".tree in " + golly.getdir("rules"))
