# Counts the number of triangles in a TriLife-* pattern or selection.
# Author: Andrew Trevorrow (andrew@trevorrow.com), Nov 2009.

import golly as g

if not g.getrule().startswith("TriLife-"):
   g.exit("This script only works with a TriLife-* rule.")

r = g.getrect()
if len(r) == 0: g.exit("There is no pattern.")

areaname = "pattern"
selr = g.getselrect()
if len(selr) > 0:
   r = selr
   areaname = "selection"

cells = g.getcells(r)
Lcount = 0
Rcount = 0
LRcount = 0
clen = len(cells)
if clen % 3 > 0: clen -= 1    # ignore padding
for i in xrange(0, clen, 3):
   state = cells[i+2]
   if state == 1: Lcount += 1
   if state == 2: Rcount += 1
   if state == 3: LRcount += 1

total = Lcount + Rcount + 2*LRcount
g.show("Number of triangles in %s: %d (L=%d R=%d LR=%d)"
       % (areaname, total, Lcount, Rcount, LRcount))
