This is a summary of the contents of the LifeHistory.zip archive.
First, the rules --

HistoricalLife:

HistoricalLife is a three-state rule equivalent to Conway's Life.
It adds an extra non-interacting cell state 2 that indicates whether
a cell has been alive (State 1) in a previous generation.  Running
patterns in this rule is a faster equivalent of running an "envelope"
script in Conway's Life.

Unlike the "envelope" scripts, in these rules the history is stored
in the same layer as the pattern, which makes editing much easier:
in particular, history cells will overwrite ON cells.  This makes it
possible, for example, to paste one phase of an oscillator directly
over another phase -- a single-step rephasing operation, without the
problem of bounding-box corners potentially blanking out other nearby
parts of the pattern (as can happen with COPY-mode pasting.)

This version of HistoricalLife has an optimized rule table (12 rules
instead of 87) and an alternate .colors file -- ON cells are green.


LifeHistory:

The "LifeHistory" rule borrows ideas and colors from Brice Due's "BeforeAfterChange" rule variants from Mirek's Cellebration.
It's a seven-state superset of HistoricalLife, allowing optional
ON and OFF "marked" cells as well as history cells.

There is also a separate yellow marked ON state, a "start" state
(since a cell can't return to this state once it turns off).  This
can be used to mark input signals or other cell groups that share a
particular function.

A gray "killer cell" state has also been added, which turns off any ON
cells that come in contact with it.  The intended use for this state
is to mark off sub-regions in a larger "stamp collection"-type pattern,
so that a pattern in one area does not accidentally affect patterns
in another area.

Cell state 3 (marked ON) changes to State 4 (marked OFF = red) when
it dies, and back to State 3 if it turns on again later.  Normal ON
cells are green, as in the optimized HistoricalLife rule.  State 3 is
a slightly greenish white to differentiate it from standard colors
for two-state Life, and State 2 is a darker shade of blue.


LifeHistoryClear:

The "LifeHistoryClear" rule removes all history cells from a pattern
after one tick, and does nothing after that.  The pattern can then be
switched to a regular Life rule, or back to LifeHistory to regenerate
the envelope after editing.  This is not as efficient as using scripts
(see below) but it will work even if Python and Perl aren't installed.


Copying and Pasting:

Pasting standard Life or HistoricalLife patterns into a LifeHistory
universe works cleanly, and the reverse is mostly true, too -- the
marked cells are lost.  Pasting HistoricalLife or LifeHistory patterns
into a regular two-state universe is fairly painful, because State 2,
State 4, and State 6 cells are automatically reduced to State 1 (instead
of State 0).  In these cases, the conversion scripts should be used.

Here's a sample LifeHistory pattern (also works in HistoricalLife):

#C p256 oscillator with marked Herschel locations
#C The top Herschel is 'marked ON' (state 3), others are 'marked OFF'
x = 49, y = 49, rule = LifeHistory
31.2A$31.2A5.2A$38.2A3$7.2A8.2A17.2A$7.2A9.A17.2A$18.A.A21.2A$19.2A
21.2A$.2A$.2A$5.2A$5.2A15.C$22.C.C$22.3C$24.C$2A$2A41.A$41.3A$40.A$
40.2A2$34.3D$34.D$13.3D17.3D$14.D$12.3D2$7.2A$8.A$5.3A$5.A41.2A$47.2A
$24.D$24.3D$24.D.D$26.D15.2A$42.2A$46.2A$46.2A$5.2A21.2A$5.2A21.A.A$
11.2A17.A9.2A$11.2A17.2A8.2A3$9.2A$9.2A5.2A$16.2A!

You may want to change Golly's preference settings to allow rule
changes to occur automatically when pasting into an empty universe:
File > Preferences > Edit > only change rule if one is specified...


Scripts:

The included Python and Perl scripts can switch a Life pattern back
and forth between standard Conway's Life rules and the HistoricalLife
or LifeHistory rules.  Assign keyboard shortcuts for quick access to
these scripts.  They can be run even while a pattern is generating,
with various visual effects.  For example, try ToLifeHistoryMarked.py
with signal circuitry like constructor-memory-loop.rle or one of the
racetrack patterns in Golly's Signal-Circuitry folder.


ToLifeHistory.py / ToLifeHistory.pl:

This script applies the LifeHistory rule to the current universe.
Like the other scripts in this series, it assumes that any patterns
in the universe are standard Conway's Life patterns -- there are no
tests for incompatible starting rules, so use at your own risk.


ToLifeHistoryMarked.py / ToLifeHistoryMarked.pl:

This script applies the LifeHistory rule to the current universe, but
also changes all State 1 cells to State 3.  This produces a persistent
"afterimage" of stationary red cells (or off-white if they're ON) marking
the original ON cell positions.  Running the script again on a marked
LifeHistory pattern will superimpose a second afterimage of the current
set of ON cells.


ToLife.py / ToLife.pl:

This script cleans up all LifeHistory / HistoricalLife cells
appropriately and switches back to the standard QuickLife algorithm
for Conway's Life.