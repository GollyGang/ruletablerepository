# Switch current pattern to five-state LifeHistory rule
# Author: Dave Greene, April 2009.

use strict;

g_setrule("LifeHistory");
