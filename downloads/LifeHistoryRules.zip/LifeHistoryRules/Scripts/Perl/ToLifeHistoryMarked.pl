# Switch current pattern to LifeHistory rule
# Author: Dave Greene, April 2009.

use strict;

g_setrule("LifeHistory");
my @cells=@{g_getcells(g_getrect())};
my $length = @cells;
for (my $i=2; $i<$length; $i+=3) @cells[$i]=3 if @cells[$i]==1;
g_putcells(\@cells);