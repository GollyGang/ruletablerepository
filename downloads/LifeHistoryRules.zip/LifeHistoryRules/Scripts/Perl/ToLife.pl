# Switch current pattern to standard HashLife algorithm and Conway's Life rule
# Author: Dave Greene, April 2009.

use strict;

if (g_getrule() eq "LifeHistory" || g_getrule() eq "HistoricalLife")
{
   # unmark any marked cells
   my @cells=@{g_getcells(g_getrect())};
   for (my $i=2; $i<scalar @cells; $i+=3) { @cells[$i]%=2; }
   g_select(g_getrect());
   g_clear(0);
   g_select();
   g_putcells(\@cells);
}
g_setrule("Life");
g_setalgo("HashLife");