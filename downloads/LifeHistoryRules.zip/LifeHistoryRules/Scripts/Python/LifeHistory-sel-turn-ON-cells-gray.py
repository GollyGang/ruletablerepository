# Switch current pattern to LifeHistory rule
# Author: Dave Greene, September 2010.

import golly as g

if len(g.getrect())==0: g.exit("There is no pattern.")
if len(g.getselrect()) == 0:
   g.exit("No selection.")

g.setrule("LifeHistory")
cells=g.getcells(g.getselrect())
for i in xrange(2,len(cells), 3):
   if cells[i]==1:
      cells[i]=6
g.putcells(cells)