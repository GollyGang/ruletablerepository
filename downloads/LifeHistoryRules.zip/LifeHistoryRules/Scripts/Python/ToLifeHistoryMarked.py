# Switch current pattern to LifeHistory rule
# Author: Dave Greene, April 2009.

import golly as g

g.setrule("LifeHistory")
cells=g.getcells(g.getrect())
for i in xrange(2,len(cells), 3):
   if cells[i]==1:
      cells[i]=3
g.putcells(cells)