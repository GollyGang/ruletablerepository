# Switch current pattern to standard HashLife algorithm and Conway's Life rule
# Author: Dave Greene, April 2009.

import golly as g

# g.setrule("LifeHistoryClear")
# t=g.getgen()
# g.run(1)
# g.setgen(t)
if g.getrule()=="LifeHistory" or g.getrule()=="HistoricalLife":
   # unmark any marked cells
   cells=g.getcells(g.getrect())
   for i in xrange(2,len(cells), 3):
      cells[i]=cells[i]%2
   g.select(g.getrect())
   g.clear(0)
   g.select([])
   g.putcells(cells)
g.setrule("Life")
g.setalgo("HashLife")