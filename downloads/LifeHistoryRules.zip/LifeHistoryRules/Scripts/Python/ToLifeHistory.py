# Switch current pattern to five-state LifeHistory rule
# Author: Dave Greene, April 2009.

import golly as g

g.setrule("LifeHistory")
