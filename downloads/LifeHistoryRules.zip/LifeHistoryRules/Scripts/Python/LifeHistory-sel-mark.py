# Switch current selected pattern to marked LifeHistory rule
# Author: Dave Greene, April 2009.

import golly as g

if len(g.getrect())==0: g.exit("There is no pattern.")
if len(g.getselrect()) == 0:
   g.exit("There is no selection.")

g.setrule("LifeHistory")
cells=g.getcells(g.getselrect())
for i in xrange(2,len(cells), 3):
   if cells[i]<3:
      cells[i]+=2
g.putcells(cells)