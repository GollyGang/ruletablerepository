# Cycle the LifeHistory color of all cells in the selection that match the current drawing color.
# ON cells remain ON, OFF cells remain OFF, gray killer cells (state 6) are left out of the cycle,
# and once a cell is changed to state 0, it remains there.
#
# This script can be used to mark selected ON cells with state 3 or state 5,
# or to remove 'envelope' cells (state 2) from a pattern.
# Author:  Dave Greene, 19 September 2010

import golly as g
if len(g.getrect())==0: g.exit("There is no pattern.")
r = g.getselrect()
if len(r)==0: g.exit("There is no selection.")

g.setrule("LifeHistory")
state = g.getoption("drawingstate") 

clist = g.getcells(r)
clistnew = []
newclr = state - 2
if newclr<0: newclr += 6

for i in range(0,len(clist)-1,3):
   if clist[i+2]==state: clistnew += [clist[i],clist[i+1],newclr]
if not len(clistnew) % 2: clistnew += [0]
g.putcells(clistnew,0,0,1,0,0,1,"copy")
g.setoption("drawingstate",newclr)