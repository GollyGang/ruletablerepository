# Change the LifeHistory color of all cells in the selection that match the current drawing color.
# The user chooses the new color by changing the drawing state while the script is running.

from time import sleep

import golly as g
if len(g.getrect())==0: g.exit("There is no pattern.")
r = g.getselrect()
if len(r)==0: g.exit("There is no selection.")

g.setrule("LifeHistory")
state = g.getoption("drawingstate") 

g.show("Change the drawing state to the desired color for state " + str(state))
while g.getoption("drawingstate") == state:
   sleep(.1)

clist = g.getcells(r)
clistnew = []
newclr = state - 2
if newclr<0: newclr += 6

for i in range(0,len(clist)-1,3):
   if clist[i+2]==state: clistnew += [clist[i],clist[i+1],newclr]
if not len(clistnew) % 2: clistnew += [0]
g.putcells(clistnew,0,0,1,0,0,1,"copy")
g.setoption("drawingstate",newclr)