Date: Wed, 18 Mar 2009 20:54:49 +0100
From: Francois Boisson <fboisson@laposte.net>
To: tim.hutton@gmail.com
Subject: colored game of life.

Well,

More then ten years ago, I downloaded the Al Hansen Life-Game program and, to
thank him, have made a coloured version of this game.
Yesterday, I have discovered golly. So I have made a table for this variant
and join it to this mail.

The idea is that when a cell borns, it have 3 parents. So there are four
colors, say 1, 2, 3 and 4.

If the three parents are of three differents colors, the new cell becomes the
of fourth color: colors 1,2,3 -> color 4 for instance.
If there is two parents of the same color, the new cell becomes of this
colour: colors 1,2,2 -> color 2 for instance.

In the file you will find (very small) exemples of multicolor ships.

I don't know if you know this variant, I never see this variant anywhere and I
don't know if it's a good variant. Nevertheless, perhaps you like it.

Regards

Fran�ois Boisson
(France, excuse my english, j'essaye de bien l'�xcrire mais �a n'est pas
simple!)

---------------------------------------------------------------

Date: Wed, 18 Mar 2009 21:42:10 +0100
From: Francois Boisson <francois@boisson.homeip.net>
To: tim.hutton@gmail.com
Subject: Re: Life

Here is an example of a gun of two coloured then three coloured ships.
It's really funny.

Regards

Fran�ois Boisson

---------------------------------------------------------------

Instructions for use:
1) copy the .table file into your Rules folder
2) open the .rle files in Golly - the lifecolor rule should load automatically.
