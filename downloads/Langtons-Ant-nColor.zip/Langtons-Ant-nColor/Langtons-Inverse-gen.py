# generator for Langton's inverse rules
# inspired by Aldoaldoz: http://www.youtube.com/watch?v=1X-gtr4pEBU
# written by Dean Hickerson (10/20/2009), based on Tim Hutton's "Langtons-Ant-gen.py"

import golly
import random

dirs=['N','E','S','W']
deltadir={'L':-1, 'R':1}
vars = ['a','b','c','d']

prefix = 'LangtonsInverse'

spec = golly.getstring(
'''This script will create a Langton's inverse Ant CA for a given string of actions,

which is the inverse of the CA created by Tim Hutton's Langtons-Ant-gen.py.

Enter string:''', 'RL', 'Enter string:')

# compute the number of symbols
n = len(spec) # number of symbols in the turing machine

# problem if we try to export more than 255 states
if 5*n>255:
    golly.warn("Number of states required exceeds Golly's limit of 255\n\nMaximum 51 turns allowed.")
    golly.exit()

# write a rule table file in user's rules directory
f=open(golly.getdir('rules')+prefix+'-'+spec+'.table', 'w')
f.write('''# Rule table written automatically by Langtons-Inverse-gen.py
# for the move-sequence: '''+spec+'''
#
''')

f.write('# -----------------------------empty squares---------------------\n')
f.write('# states 0-'+str(n-1)+'\n')
f.write('# ----------------------------------------------ant is here------\n')
for i in range(n):
    f.write('# states '+str(n+4*i)+'-'+str(n+4*i+3)+' : ant on a square in state '+str(i)+' facing '+','.join(dirs)+'\n')
f.write('# ---------------------------------------------------------------\n')

f.write('n_states:'+str(n+4*n)+'\nneighborhood:vonNeumann\nsymmetries:none\n')

# first we need some variables:
f.write('\n# ----------- variables: -----------\n\n')
f.write('# any empty square:\n')
for i in range(4):
    f.write('var '+vars[i]+'={'+','.join(map(str,range(n)))+'}\n')
for i in range(n):
    f.write('# a square in state '+str(i)+' with an ant on it:\n')
    f.write('var ant'+str(i)+'={'+','.join(map(str,range(n+4*i,n+4*i+4)))+'}\n')

f.write('# an ant facing N\n')
f.write('var antN={' + ','.join(map(str,range(n  ,5*n  ,4))) + '}\n')
f.write('# an ant facing E\n')
f.write('var antE={'+','.join(map(str,range(n+1,5*n+1,4))) + '}\n')
f.write('# an ant facing S\n')
f.write('var antS={'+','.join(map(str,range(n+2,5*n+2,4))) + '}\n')
f.write('# an ant facing W\n')
f.write('var antW={'+','.join(map(str,range(n+3,5*n+3,4))) + '}\n')

f.write('\n# ----------- transitions: -----------\n\n')

# ant entered this square
f.write('# an ant entered this square: return to empty state\n')
for i in range(n):
    f.write('ant'+str(i)+','+','.join(vars)+','+str(i)+'\n')
    
# the ant moved N from this square
f.write('\n# an ant moved N from this square: decrement state and point ant E or W\n')
for state in range(n): # the state was incremented to this value
    oldstate = (state-1)%n
    dir = (0-deltadir[spec[oldstate]])%4
    f.write(str(state) + ',antN,b,c,d,' + str(n+dir+4*oldstate) + '\n')
    
# the ant moved E from this square
f.write('\n# an ant moved E from this square: decrement state and point ant S or N\n')
for state in range(n): # the state was incremented to this value
    oldstate = (state-1)%n
    dir = (1-deltadir[spec[oldstate]])%4
    f.write(str(state) + ',a,antE,c,d,' + str(n+dir+4*oldstate) + '\n')
    
# the ant moved S from this square
f.write('\n# an ant moved S from this square: decrement state and point ant W or E\n')
for state in range(n): # the state was incremented to this value
    oldstate = (state-1)%n
    dir = (2-deltadir[spec[oldstate]])%4
    f.write(str(state) + ',a,b,antS,d,' + str(n+dir+4*oldstate) + '\n')
    
# the ant moved W from this square
f.write('\n# an ant moved W from this square: decrement state and point ant N or S\n')
for state in range(n): # the state was incremented to this value
    oldstate = (state-1)%n
    dir = (3-deltadir[spec[oldstate]])%4
    f.write(str(state) + ',a,b,c,antW,' + str(n+dir+4*oldstate) + '\n')

f.close()

# now we can switch to the new rule
golly.setrule(prefix+'-'+spec)
golly.setgen('0')
golly.show('Created '+prefix+'-'+spec+'.table, and selected this rule.')
