# generator for Langton's Ant rules
# inspired by Aldoaldoz: http://www.youtube.com/watch?v=1X-gtr4pEBU
# contact: tim.hutton@gmail.com

import golly
import random

dirs=['N','E','S','W']
opposite_dirs=[2,3,0,1] # index of opposite direction
turn={ # index of new direction given a left or right turn
'L':[3,0,1,2],
'R':[1,2,3,0]
}
vars = ['a','b','c','d']

prefix = 'LangtonsAnt' 
# (We choose a different name to the inbuilt Langtons-Ant rule to avoid
#  name collision between the rules we output and the existing icons.)

spec = golly.getstring(
'''This script will create a Langton's Ant CA for a given string of actions.

The string specifies which way to turn when standing on a square of each state.

Examples: RL (Langton's Ant), LLRR (Cardioid), LRRL (structure)

Enter string:''', 'RL', 'Enter string:')

# compute the number of symbols
n = len(spec) # number of symbols in the turing machine

# problem if we try to export more than 255 states
if 5*n>255:
    golly.warn("Number of states required exceeds Golly's limit of 255\n\nMaximum 51 turns allowed.")
    golly.exit()

# write a rule table file in user's rules directory
f=open(golly.getdir('rules')+prefix+'-'+spec+'.table', 'w')
f.write('''# Rule table written automatically by Langtons-Ant-gen.py
# for the move-sequence: '''+spec+'''
#
# A generalisation of Langton's Ant to n-colors. For each state i that the
# ant finds itself on:
# 1. turn 90 degrees R or L (depending on the i'th letter of the move sequence)
# 2. increment the state of the cell (modulo n)
# 3. move forward one square
#
''')

f.write('# -----------------------------empty squares---------------------\n')
f.write('# states 0-'+str(n-1)+'\n')
f.write('# ----------------------------------------------ant is here------\n')
for i in range(n):
    f.write('# states '+str(n+4*i)+'-'+str(n+4*i+3)+' : ant on a square in state '+str(i)+' facing '+','.join(dirs)+'\n')
f.write('# ---------------------------------------------------------------\n')

f.write('n_states:'+str(n+4*n)+'\nneighborhood:vonNeumann\nsymmetries:none\n')

# first we need some variables:
f.write('\n# ----------- variables: -----------\n\n')
f.write('# any empty square:\n')
for i in range(4):
    f.write('var '+vars[i]+'={'+','.join(map(str,range(n)))+'}\n')
for i in range(n):
    f.write('# a square in state '+str(i)+' with an ant on it:\n')
    f.write('var ant'+str(i)+'={'+','.join(map(str,range(n+4*i,n+4*i+4)))+'}\n')

f.write('\n# ----------- transitions: -----------\n\n')

# ant always leaves the square
f.write('# an ant is leaving this square: increment it modulo '+str(n)+'\n')
for i in range(n):
    f.write('ant'+str(i)+','+','.join(vars)+','+str((i+1)%n)+'\n')
    
# the ant is entering this square
f.write('\n# an ant is entering this square:\n')
for from_state in range(n): # the ant is currently on this state
    for old_dir in range(4): # the ant is currently facing this way
        move = spec[from_state] # the ant will turn this way
        new_dir = turn[move][old_dir] # the ant will end up facing this way
        for central_state in range(n): # the central square is in this state
            f.write(str(central_state))
            for nbor in range(4):
                if nbor == opposite_dirs[new_dir]:
                    # ant coming from here
                    f.write(','+str(n+4*from_state+old_dir))
                else:
                    # empty square
                    f.write(','+vars[nbor])
            f.write(','+str(n+4*central_state+new_dir))
            f.write(' # ant to the '+dirs[opposite_dirs[new_dir]]+' facing '+dirs[old_dir]+' on state '+str(from_state)+' turns '+move+' and advances one square')
            f.write('\n')
        
f.close()

# now we can switch to the new rule
golly.setrule(prefix+'-'+spec)
golly.new(prefix+'-'+spec+' demo')
golly.setcell(0,0,n+3) # start with an ant facing west
golly.show('Created '+prefix+'-'+spec+'.table, and selected this rule.')
