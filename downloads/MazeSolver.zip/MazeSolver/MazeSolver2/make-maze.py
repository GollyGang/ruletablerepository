# Build a random, connected maze for MazeSolver or MazeSolver2 rule
# using an iterative algorithm to avoid recursion limits.
# Author: Andrew Trevorrow (andrew@trevorrow.com), Dec 2010.

import golly as g
from glife import validint
from random import randint
from time import time

# important states in MazeSolver/MazeSolver2 rule
wall = 1
start = 2
finish = 3

# type of lines used inside maze
diagonal = 'd'
orthogonal = 'o'
straight = 's'
wavy = 'w'

# --------------------------------------------------------------------

def all_neighbors_empty(x, y):
   return g.getcell(x+1, y+1) == 0 and \
          g.getcell(x-1, y-1) == 0 and \
          g.getcell(x+1, y-1) == 0 and \
          g.getcell(x-1, y+1) == 0 and \
          g.getcell(x+1, y  ) == 0 and \
          g.getcell(x-1, y  ) == 0 and \
          g.getcell(x  , y+1) == 0 and \
          g.getcell(x  , y-1) == 0

# --------------------------------------------------------------------

def num_neighbors(x, y):
   n = 0
   if g.getcell(x+1, y+1) > 0: n +=1
   if g.getcell(x-1, y-1) > 0: n +=1
   if g.getcell(x+1, y-1) > 0: n +=1
   if g.getcell(x-1, y+1) > 0: n +=1
   if g.getcell(x+1, y  ) > 0: n +=1
   if g.getcell(x-1, y  ) > 0: n +=1
   if g.getcell(x  , y+1) > 0: n +=1
   if g.getcell(x  , y-1) > 0: n +=1
   return n

# --------------------------------------------------------------------

def possible_moves(xpos, ypos, directions, maxdirs):
   # find list of all possible moves from given non-empty cell
   l = []
   for i in xrange(maxdirs):
      xinc, yinc = directions[i]
      x = xpos + xinc
      y = ypos + yinc
      n = num_neighbors(x, y)
      if g.getcell(x, y) == 0 and (n == 1 or
            # allow move to isolated empty cell next to outer wall
            (x == 1 or y == 1 or x == cols or y == rows) and n == 4):
         l.append(directions[i])
   return l

# --------------------------------------------------------------------

def draw_straight_line(x, y, xinc, yinc):
   # draw a straight line in given direction until we hit wall
   # or get too close to another line
   while True:
      g.setcell(x, y, wall)
      x += xinc
      y += yinc
      if g.getcell(x, y) > 0: return
      n = num_neighbors(x, y)
      if (x == 1 or y == 1 or x == cols or y == rows) and n == 4:
         g.setcell(x, y, wall)
         return
      if n > 1: return

# --------------------------------------------------------------------

def draw_wavy_line(x, y):
   # draw a wavy line until we hit wall or get too close to another line
   # (note that we only use a few directions so we get long wavy lines
   # rather than short loopy lines)
   d = randint(1,4)
   if d == 1:
      # move generally NE
      directions = [ (1,-1), (0,-1), (1,0) ]
   elif d == 2:
      # move generally SE
      directions = [ (1,1), (0,1), (1,0) ]
   elif d == 3:
      # move generally SW
      directions = [ (-1,1), (0,1), (-1,0) ]
   else:
      # move generally NW
      directions = [ (-1,-1), (0,-1), (-1,0) ]
   maxdirs = len(directions)
   while True:
      g.setcell(x, y, wall)
      if x == 1 or y == 1 or x == cols or y == rows: break
      p = possible_moves(x, y, directions, maxdirs)
      if len(p) == 0: break
      xinc, yinc = p[ randint(0,len(p)-1) ]
      x += xinc
      y += yinc

# --------------------------------------------------------------------

def draw_maze(cols, rows, linetype, density):
   g.show("Creating maze...")
   oldsecs = time()
   
   # draw outer walls, with top left corner at 0,0
   for i in xrange(cols+2): g.setcell(i, 0, wall)
   for i in xrange(cols+2): g.setcell(i, rows+1, wall)
   for i in xrange(rows): g.setcell(0, i+1, wall)
   for i in xrange(rows): g.setcell(cols+1, i+1, wall)
   g.fit()

   if linetype != wavy:
      if linetype == diagonal:
         directions = [ (1,1), (1,-1), (-1,1), (-1,-1) ]
      elif linetype == orthogonal:
         directions = [ (1,0), (-1,0), (0,1), (0,-1) ]
      else:
         # linetype == straight, so use all directions
         directions = [ (1,0), (-1,0), (0,1), (0,-1),
                        (1,1), (1,-1), (-1,1), (-1,-1) ]
      maxdir = len(directions) - 1
   
   while True:
      # randomly pick an empty cell with 8 empty neighbors
      found = False
      for i in xrange(density):
         x = randint(1, cols)
         y = randint(1, rows)
         if g.getcell(x, y) == 0 and all_neighbors_empty(x, y):
            if linetype == wavy:
               draw_wavy_line(x, y)
            else:
               xinc, yinc = directions[ randint(0,maxdir) ]
               draw_straight_line(x, y, xinc, yinc)
            
            g.dokey( g.getkey() )         # allow keyboard interaction
            newsecs = time()
            if newsecs - oldsecs >= 1.0:  # do an update every sec
               oldsecs = newsecs
               g.update()
            
            found = True
            break
      if not found: break
   
   # put start in top left corner and finish in bottom right corner
   g.setcell(1, 1, start)
   g.setcell(cols, rows, finish)
   
   g.show("")

# --------------------------------------------------------------------

def save_settings(filename, settings):
   try:
      f = open(filename, 'w')
      f.write(settings)
      f.close()
   except:
      g.warn("Unable to save given settings in file:\n" + filename)

# --------------------------------------------------------------------

inifile = g.getdir("data") + "make-maze.ini"
previous = "300 300 o 10"
try:
   f = open(inifile, 'r')
   previous = f.readline()
   f.close()
except:
   # should only happen 1st time (inifile doesn't exist)
   pass

result = g.getstring("Enter the number of columns and rows in the maze\n" +
                     "(both numbers must be from 3 to 1000);\n" +
                     "then an optional line type where d = diagonal,\n" +
                     "o = orthogonal, s = straight (diagonal/orthogonal)\n" +
                     "and w = wavy (the default is orthogonal);\n" +
                     "then an optional density value from 1 to 100\n" +
                     "(the default is 10):",
                     previous, "Make a maze")
crld = result.split()
if len(crld) == 0: g.exit()
if len(crld) == 1: crld.append(crld[0])   # set rows to same value as cols
if len(crld) == 2: crld.append("o")       # append default line type
if len(crld) == 3: crld.append("10")      # append default density

if not validint(crld[0]): g.exit("Bad columns value: " + crld[0])
if not validint(crld[1]): g.exit("Bad rows value: " + crld[1])
cols = int(crld[0])
rows = int(crld[1])
if rows < 3 or cols < 3 or rows > 1000 or cols > 1000:
   g.exit("Maze dimension must be from 3 to 1000.")

linetype = crld[2]
if not (linetype == diagonal or linetype == orthogonal or
        linetype == straight or linetype == wavy):
   g.exit("Unknown line type: " + crld[2])

if not validint(crld[3]): g.exit("Bad density value: " + crld[3])
density = int(crld[3])
if density < 1 or density > 100:
   g.exit("Density value must be from 1 to 100.")

save_settings(inifile, result)

g.new("maze")
if not g.getrule().startswith("MazeSolver"):
   g.setrule("MazeSolver2")

draw_maze(cols, rows, linetype, density)
