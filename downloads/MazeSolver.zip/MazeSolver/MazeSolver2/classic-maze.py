# Maze generation script for Golly 2.x -- version 1.02.
# Uses Andrew Trevorrow's "MazeSolver2" rule,
#   or Adam Goucher's original "MazeSolver".
# Dave Greene, 12/12/2010; compatibility changes by Andrew Trevorrow.
#
# The program creates a rectangular maze with exactly one path
#    between any two points (assuming width-1 passageways.)
# First two parameters are width and height of rectangle (number of rooms)
# Third parameter is the branch length:  a value of 1 means the algorithm
#    abandons a path almost immediately and starts again at a random location;
#    a high value makes it progressively less likely that a path will be
#    abandoned (though the algorithm will retrace the most recent path as
#    necessary if it reaches a dead end.)
# Fourth parameter controls the frequency of screen updates -- e.g., a value
#    of 1 will display every change to the maze; a value larger than the total
#    number of rooms will disable screen updates but generate the maze as
#    quickly as possible.
# Fifth and sixth parameters are room width and wall width -- 1,1 is fastest.

from glife import *
from string import lower
from random import *
import golly as g
import copy

# use previous settings, if they exist
inifile = g.getdir("data") + "classic-maze.ini"
previous = "100 80 500 99 1 1"
try:
   f = open(inifile, 'r')
   previous = f.readline()
   f.close()
except:
   # should only happen 1st time (inifile doesn't exist)
   pass

answer = g.getstring("Enter maze width and height, and optional branch length (1=short, 999=long)," +
                     "\n speed (1=slow,999=fast), room width, and wall width:",
                     previous, "Select maze size and options")
xybsrw = (answer+" . . . . . .").split()
x, y, branch, speed, rw, ww = 250, 250, 10, 99, 1, 1
if validint(xybsrw[0]):      x = int(xybsrw[0])
if validint(xybsrw[1]):      y = int(xybsrw[1])
if validint(xybsrw[2]): branch = int(xybsrw[2])
if validint(xybsrw[3]):  speed = int(xybsrw[3])
if validint(xybsrw[4]):     rw = int(xybsrw[4])
if validint(xybsrw[5]):     ww = int(xybsrw[5])
if x<=0: x = 100
if y<=0: y = 100
if branch<=0: branch = 1
if speed<=0: speed = 1
if rw<=0: rw = 1
if ww<=0: ww = 1
if x*y > 250000:
   g.note("Maze area is greater than 250,000 -- truncating.")
   if x > 500: x = 500
   if y > 500: y = 500

# save settings for next time
try:
   f = open(inifile, 'w')
   f.write(answer)
   f.close()
except:
   g.warn("Unable to save given settings in file:\n" + filename)

directions = [0,1,2,3]
dx, dy = [1,0,-1,0], [0,-1,0,1]  # steps to adjacent rooms for directions 0, 1, 2, 3
adjx, adjy = [0,0,-ww,0], [0,-ww,0,0]                           # deltas for building new
width, height = [rw+ww, rw, rw+ww, rw], [rw, rw+ww, rw, rw+ww]  # rooms in each direction

# initialize maze arrays
rooms, visited = [[[4]]*(x+2)], [[True]*(x+2)]
for j in range(y):
   temp=[[4]]
   for i in range(x):
      shuffle(directions)
      temp.append([4] + copy.copy(directions))
   rooms.append(temp+[[4]])
   visited.append([True] + [False]*x + [True])
rooms.append([[4]]*(x+2))
visited.append([True]*(x+2))

# create appropriate-sized block to be carved out
maze = pattern((str(x*(rw+ww) + ww) + "o$")*(y*(rw+ww)+ww) + "!")

# only change rule if current rule is not a MazeSolver variant
if not g.getrule().startswith("MazeSolver"):
   try:
      g.setrule("MazeSolver2")
   except:
      g.setrule("MazeSolver")

maze.display("Maze " + answer)

# pick a random start location and initialize the room array
roomlist = [[randint(1,x), randint(1,y)]]
visited[roomlist[-1][1]][roomlist[-1][0]] = True
g.select([roomlist[-1][0]*(rw+ww)-rw,roomlist[-1][1]*(rw+ww)-rw,rw,rw])
g.clear(0)
count = 0

while len(roomlist):           # main loop -- continues until active room list is empty
   oldx, oldy = roomlist[-1][0], roomlist[-1][1]
   while 1:                    # look at all possible directions from most recent room
      if rooms[oldy][oldx] == [4]:
         junk = roomlist.pop() # tried all directions -- remove room from active list
         break
      dir = rooms[oldy][oldx].pop()
      newx, newy = oldx + dx[dir], oldy + dy[dir]
      if not visited[newy][newx]:
         roomlist.append([newx,newy])
         visited[newy][newx] = True

         r = [oldx*(rw+ww) - rw + dx[dir]*rw + adjx[dir], \
              oldy*(rw+ww) - rw + dy[dir]*rw + adjy[dir], \
              width[dir], \
              height[dir]]
         g.select(r)
         g.clear(0) # this rectangle includes the new room and the adjoining wall
         if count % speed == 0:
            g.select([])
            g.show("Active room list length = " + str(len(roomlist)))
            g.update()
         count+=1
         break
   # re-order the list at random intervals at a random spot, based on branch parameter --
   if random() < 1.0/(branch+1) and len(roomlist)>1:
      i=randint(1,len(roomlist))
      roomlist = roomlist[i:] + roomlist[:i]

g.select([])
g.setcell(ww,ww,2)                   # start cell
g.setcell(x*(ww+rw)-1,y*(ww+rw)-1,3) # end cell
g.show("")
