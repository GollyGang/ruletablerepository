# Flip selection east-west in Snakes rule, swapping states
# appropriately.
# Author: Dean Hickerson, 11/8/2011

from glife import *

##########################################################################

B0  = 1     # Background bit
B1  = 2
T0  = 3     # Signal tail / tentative turn direction
T1  = 4
SH0 = 5     # Shrink signal head
SH1 = 6
RH0 = 7     # Reverse signal head
RH1 = 8
C0  = 9     # Verify that growth occurred
C1  = 10 
N   = 11    # New cell
L   = 12    # Left
R   = 13    # Right 
F   = 14    # Forward
A   = 15    # Available for growth
V   = 16    # Venom
Z   = 17    # Used in Snakes-history rule

states =  [0, B0,B1, T0,T1, SH0,SH1, RH0,RH1, C0,C1, N, L,R, F, A, V, Z]
flipped = [0, B1,B0, T1,T0, SH1,SH0, RH1,RH0, C1,C0, N, R,L, F, A, V, Z]

##########################################################################

def flip(state):
  for i in xrange(len(states)):
    if state == states[i]:
      return flipped[i]
  golly.exit('ERROR in flip; state = ' + str(state))

##########################################################################

selrect = golly.getselrect()

if len(selrect) == 0:
  golly.exit("Selection is empty.")

cmin = selrect[0]
rmin = selrect[1]
cmax = cmin + selrect[2] - 1
rmax = rmin + selrect[3] - 1

for r in xrange(rmin, rmax+1):
  for c in xrange(cmin, cmax+1):
    golly.setcell(c, r, flip(golly.getcell(c,r)))
  for c in xrange(cmin, (cmin+cmax+1)/2):
    left = golly.getcell(c, r)
    right = golly.getcell(cmin+cmax-c, r)
    golly.setcell(c,r,right)
    golly.setcell(cmin+cmax-c,r,left)

golly.exit('Flipped columns ' + str(cmin) + '-' + str(cmax) +\
           '   Rows ' + str(rmin) + '-' + str(rmax))

