# Switch between Snakes and Snakes-history rules.
# Dean Hickerson, 3/19/2012

import golly

if golly.getrule()=='Snakes':
  golly.setrule('Snakes-history')
elif golly.getrule()=='Snakes-history':
  golly.setrule('Snakes')
else:
  golly.exit("Rule unchanged; it isn't Snakes or Snakes-history.")
