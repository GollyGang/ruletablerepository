# Create random starting patterns for snake rule.
# Prompt user for size and number of snakes to create.
# Author: Dean Hickerson, 10/5/2011-3/26/2012

from glife import *
from random import randrange
import string

B0  = 1		# Background bit
B1  = 2
T0  = 3		# Signal tail
T1  = 4
SH0 = 5		# Shrink signal head
SH1 = 6
HR0 = 7		# Reverse signal head
HR1 = 8
C0  = 9		# Verify that growth occurred
C1  = 10
N   = 11	# New cell
		# States 12-17 aren't used here


sep = 200	# Separation between snakes

short = False	# If true, use only B and N cells
		# Otherwise, use B, HS, T, and N cells

##########################################################################

def randbit():			# Random 0 or 1
   return randrange(0,2)

##########################################################################

def randpat(row, cmin, sz):
# Creates random pattern going east, north, and south from (cmin,row).

# Start at (cmin,row) and repeatedly move north (dir=0), east (dir=1), or
# south (dir=2).  North and south moves must have at least 2 easts between.

   c = cmin
   r = row
   either = True	# Both north and south available
   lastdir = 1

   if short:
      length = sz+1
   else:
      length = sz + 2 + ((sz+1)/3)

   for count in xrange(length):
      if short:
         if count==0:	cell = N
         else:		cell = [B0,B1][randbit()]
      else:
         if count==0:	cell = N
         elif count==1:	cell = [C0,C1][randbit()]
         elif count%4==0:	cell = [SH0,SH1][randbit()]
         elif count%4==3:	cell = [T0,T1][randbit()]
         else:		cell = [B0,B1][randbit()]

      golly.setcell(c, r, cell)
      if either:
         dir = randrange(0,3)		# N, E, or S
      else:
         if lastvert==0:
            dir = randrange(0,2)	# N or E
         else:
            dir = 1+randrange(0,2)	# E or S

      if dir==0:
         r = r-1
      elif dir==1:
         c = c+1
      else:
         r = r+1

      if dir==0 or dir==2:
         either = False

      if dir==1 and lastdir==1:
         either = True

      lastdir = dir

      if dir==0 or dir==2:
         lastvert = dir

##########################################################################

def getnums(str):
# Given string str, return list of strings of digits within it.
# Any substring of consecutive nondigits is treated as a separator.  E.g.
# getnums('abc 123,,,456  78xyz90.') = ['123', '456', '78', '90']
  nondigs = ''.join(map(chr, [i for i in xrange(32,48)])) + \
            ''.join(map(chr, [i for i in xrange(58,127)]))
  spaces = ''.join([' ' for i in xrange(85)])
  tbl = string.maketrans(nondigs,spaces)
  return (str.translate(tbl)).split()

##########################################################################

input = golly.getstring('Warning:  Current pattern will be deleted.\n\n'
                           'Enter size or size,count or size,rows,columns:')
args = getnums(input)

if args == ['']:
   args = []

if len(args)<1 or len(args)>3:
   golly.exit('Input should be 1, 2, or 3 numbers.')

for i in xrange(len(args)):
   if not validint(args[i]):
      golly.exit('Invalid integer.')

sz = int(args[0])

if len(args)<=1:
   rows = 1
   cols = 1
elif len(args)==2:
   rows = 1
   cols = int(args[1])
else:
   rows = int(args[1])
   cols = int(args[2])

if sz<1:
   golly.exit('Size must be at least 1.')

base = golly.getbase()
step = golly.getstep()

if rows*cols==1:
  golly.new('Random %d-snake' % sz)
else:
  golly.new('%d random %d-snakes' % (rows*cols, sz))

golly.setbase(base)
golly.setstep(step)

for row in xrange(rows):
   for col in xrange(cols):
      randpat((sz+sep)*row, (sz+sep)*col, sz)

golly.fit()
