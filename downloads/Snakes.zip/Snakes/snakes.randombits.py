# Randomize bits in selected rectangle
# Author: Dean Hickerson, 12/31/2011

from glife import *
from random import randrange

B0  = 1     # Background bit
B1  = 2
T0  = 3     # Signal tail / tentative turn direction
T1  = 4
SH0 = 5     # Shrink signal head
SH1 = 6
RH0 = 7     # Reverse signal head
RH1 = 8
C0  = 9     # Check that growth occurred
C1  = 10
N   = 11    # New cell
L   = 12    # Left
R   = 13    # Right
F   = 14    # Forward
A   = 15    # Available for growth
V   = 16    # Venom
Z   = 17    # Used in Snakes-history rule

##########################################################################

def randbit():			# Random 0 or 1
   return randrange(0,2)

##########################################################################

bb = golly.getselrect()
if len(bb)==0:
  golly.exit('Selection is empty')

minc = bb[0]
maxc = minc + bb[2] - 1
minr = bb[1]
maxr = minr + bb[3] - 1

for r in xrange(minr,maxr+1):
  for c in xrange(minc,maxc+1):
    val = golly.getcell(c,r)

    if val==B0 or val==B1:	val = B0+randbit()
    if val==T0 or val==T1:	val = T0+randbit()
    if val==SH0 or val==SH1:	val = SH0+randbit()
    if val==RH0 or val==RH1:	val = RH0+randbit()
    if val==C0 or val==C1:	val = C0+randbit()
    if val==L or val==R:	val = L+randbit()

    golly.setcell(c,r,val)

