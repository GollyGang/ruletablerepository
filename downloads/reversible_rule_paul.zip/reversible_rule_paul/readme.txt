This is an example of reversible rule by Paul Nasca.
(zynaddsubfx AT yahoo DOT com)
