# Reverse the reversible rules
# Author: Paul Nasca, 
# based on the invert script by  Andrew Trevorrow

from glife import rect
from time import time
import golly as g

r = rect( g.getselrect() )
if r.empty: g.exit("There is no selection.")

oldsecs = time()
maxstate = g.numstates() - 1

for row in xrange(r.top, r.top + r.height):
	for col in xrange(r.left, r.left + r.width):
		cell=g.getcell(col, row)
		if cell==1:
			cell=2
		else:
			if cell==2:
				cell=1
		g.setcell(col, row, cell )

g.select([])


