# Generator for AbsoluteTurmites rules. Also known as 2D Turing machines.
#
# contact: tim.hutton@gmail.com

import golly
import random
import time
import string

dirs=['N','E','S','W']
opposite_dirs = [ 2, 3, 0, 1 ]

prefix = 'AbsoluteTurmite' 

# N.B. All 'relative' Turmites (including Langton's ant and the n-Color family) 
# can be expressed as Absolute Turmites but require 4n states instead of n.
# e.g. {{{1,'E',1},{0,'W',3}},{{1,'S',2},{0,'N',0}},{{1,'W',3},{0,'E',1}},{{1,'N',0},{0,'S',2}}}
#      is a 4-state 2-color Absolute Turmite that matches Langton's ant
# Likewise all normal 1D Turing machines can be expressed as Absolute Turmites in a
# straightforward fashion.
# e.g. {{{1,'E',1},{1,'W',1}},{{1,'W',0},{1,'',0}}}
#      is a 2-state 2-color busy beaver
# In both cases the opposite transform is usually not possible. Thus Absolute Turmites 
# are a deeper generalization.

example_spec = "{{{1,'E',1},{1,'W',1}},{{1,'W',0},{1,'',0}}}"

# DEBUG: generate a random rule
import random
ns = 4
nc = 3
while True: # (we break out if ok)
    example_spec = '{'
    for state in range(ns):
        if state > 0:
            example_spec += ','
        example_spec += '{'
        for color in range(nc):
            if color > 0:
                example_spec += ','
            new_state = random.randint(0,ns-1)
            new_color = random.randint(0,nc-1)
            dir_to_move = dirs[random.randint(0,3)]
            example_spec += '{' + str(new_color) + ",'" + dir_to_move + "'," + str(new_state) + '}'
        example_spec += '}'
    example_spec += '}'
    # is rule acceptable?
    is_rule_acceptable = True
    action_table = eval(string.replace(string.replace(example_spec,'}',']'),'{','['))
    # will turmite zip off? if on color 0 with state s the turmite does (?,?,s) then rule is dull
    for state in range(ns):
        if action_table[state][0][2]==state:
            is_rule_acceptable = False
    # does Turmite change at least one color?
    changes_one = False
    for state in range(ns):
        for color in range(nc):
            if not action_table[state][color][0] == color:
                changes_one = True
    if not changes_one:
        is_rule_acceptable = False
    # does turmite get stuck in any state?
    for state in range(ns):
        changes_state = False
        for color in range(nc):
            if not action_table[state][color][2] == state:
                changes_state = True
        if not changes_state:
            is_rule_acceptable = False
    if is_rule_acceptable:
        break

'''
# input: Busy Beaver 2,2 from Wikipedia
#turing_program = ["0,A,P1,R,B","0,B,P1,L,A","1,A,P1,L,B","1,B,P1,R,H"]
#n_symbols = 2 # how many symbols on the tape (max 10 in this script)
#n_states = 2 # how many states in the finite state machine? (max 10)

# input: Busy Beaver 3,2 from Wikipedia
#turing_program = ["0,A,P1,R,B","0,B,P0,R,C","0,C,P1,L,C",
#				  "1,A,P1,R,H","1,B,P1,R,B","1,C,P1,L,A"]
#n_symbols = 2 # how many symbols on the tape (max 10 in this script)
#n_states = 3 # how many states in the finite state machine? (max 10)

# input: Busy Beaver 4,2 from Wikipedia
turing_program = ["0,A,P1,R,B","0,B,P1,L,A","0,C,P1,R,H","0,D,P1,R,D",
				  "1,A,P1,L,B","1,B,P0,L,C","1,C,P1,L,D","1,D,P0,R,A"]
n_symbols = 2 # how many symbols on the tape (max 10 in this script)
n_states = 4 # how many states in the finite state machine? (max 10)

# input: self-rep program from Calcyman
# symbols: 0,1,2,3,4,5 where 1 is T divider and 2/3/4/5 are 0/1 bits
# states: A,B,C,D,E,F,G = GRAB, W0, W1, WT, RETURN, RESTORE, CENTRE
#turing_program = [
#  "2,A,P4,R,B","3,A,P5,R,C","4,A,P4,R,A","5,A,P5,R,A","1,A,P1,R,D",
#  "0,B,P2,L,E","2,B,P2,R,B","3,B,P3,R,B","1,B,P1,R,B",
#  "0,C,P3,L,E","2,C,P2,R,C","3,C,P3,R,C","1,C,P1,R,C",
#  "0,D,P1,L,F","2,D,P2,R,D","3,D,P3,R,D","1,D,P1,R,D",
#  "0,E,P0,R,A","2,E,P2,L,E","3,E,P3,L,E","4,E,P4,L,E","5,E,P5,L,E","1,E,P1,L,E",
#  "2,F,P2,L,F","3,F,P3,L,F","4,F,P2,L,F","5,F,P3,L,F","1,F,P1,L,F","0,F,P0,R,G",
#  "2,G,P2,R,G","3,G,P3,R,G","1,G,P1,R,A" ]
#n_symbols = 6
#n_states = 7

# DEBUG: convert from a representation of 1D Turing machines:
action_table = []
for i in range(n_states):
    action_table.append([])
    for j in range(n_symbols):
        action_table[i].append([])
        action_table[i][j]=[0,'',0] # default: die
for entry in turing_program:
    transition = entry.split(',')
    color = int(transition[0])
    state = ord(transition[1])-ord('A')
    new_color = int(transition[2][1:])
    move = transition[3]
    if move == 'L': 
        move='W'
    elif move == 'R': 
        move='E'
    if transition[4] == 'H':
        move = ''
        new_state = 0
    else:
        new_state = ord(transition[4])-ord('A')
    action_table[state][color].append(new_color)
    action_table[state][color].append(move)
    action_table[state][color].append(new_state)
example_spec = repr(action_table).replace('[','{').replace(']','}')
'''

spec = golly.getstring(
'''This script will create an AbsoluteTurmite CA for a given specification.

Enter a specification string: a curly-bracketed table of n_states rows
and n_colors columns, where each entry is a triple of integers. 
The elements of each triple are:
a: the new color of the square
b: the direction(s) for the turmite to move: 'NESW'
c: the new internal state of the turmite

Example:
{{{1,'E',1},{1,'W',1}},{{1,'W',0},{1,'',0}}}
(example pattern #1)
Has 2 states and 2 colors. The triple {1,'W',0} says: 
1. set the color of the square to 1
2. move West
3. adopt state 0 and move forward one square
This is a 1D busy beaver

CAUTION! Large tables take a long time to generate!

Enter specification string:
(default is a random example)''', example_spec, 'Enter Absolute Turmite specification:')

# convert the specification string into action_table[state][color]
# (convert Mathematica code to Python and run eval)
action_table = eval(string.replace(string.replace(spec,'}',']'),'{','['))
n_states = len(action_table)
n_colors = len(action_table[0])
# (N.B. The terminology 'state' here refers to the internal state of the finite
#       state machine that each turmite is using, not the contents of each Golly
#       cell. We use the term 'color' to denote the symbol on the 2D 'tape'. The
#       actual 'Golly state' in this emulation of turmites is given by the 
#       "encoding" section below.)

# TODO: check table is full and valid

total_states = n_colors + n_colors*n_states

# problem if we try to export more than 255 states
if total_states > 255:
    golly.warn("Number of states required exceeds Golly's limit of 255.")
    golly.exit()

# encoding: 
# (0-n_colors: empty square)
def encode(c,s):
    # turmite on color c in state s
    return n_colors + n_states*c + s

# decoding:
def has_turmite(s): 
    return s>=n_colors
def get_state(s): # assume has_turmite(s)
    return (s-n_colors)%n_states
def get_color(s):
    if not has_turmite(s): return s
    else: return int((s-n_colors) / n_states)

# http://rightfootin.blogspot.com/2006/09/more-on-python-flatten.html
def flatten(l, ltypes=(list, tuple)):
    ltype = type(l)
    l = list(l)
    i = 0
    while i < len(l):
        while isinstance(l[i], ltypes):
            if not l[i]:
                l.pop(i)
                i -= 1
                break
            else:
                l[i:i + 1] = l[i]
        i += 1
    return ltype(l)
    
# convert the string to a form we can embed in a filename
spec_string = ''.join(map(str,map(str,flatten(action_table)))) 
# (ambiguous but we have to try something)

def transition_function(c,nbors): # nbors: [n,e,s,w]
    new_color = get_color(c) # unless something changes it
    if has_turmite(c):
        # color of this square changes as the turmite leaves
        new_color = action_table[get_state(c)][get_color(c)][0]
    is_turmite_arriving = False # until we discover otherwise
    turmite_new_state = 0
    for from_dir in range(4):
        from_square = nbors[from_dir]
        if not has_turmite(from_square):
            continue
        # is an turmite arriving from this direction?
        if dirs[opposite_dirs[from_dir]] in action_table[get_state(from_square)][get_color(from_square)][1]:
            # if multiple turmites arrive they annihilate each other
            if is_turmite_arriving:
                is_turmite_arriving = False
                break # (we don't need to check any other neighbors)
            is_turmite_arriving = True
            turmite_new_state = action_table[get_state(from_square)][get_color(from_square)][2]
    if is_turmite_arriving:
        return encode(new_color,turmite_new_state)
    else:
        return new_color
        
# a wrapper for the transition function, to re-order the params
# (order for four neighbors is n, w, e, s, c)
def f(a): return transition_function(a[4],[a[0],a[2],a[3],a[1]])
    
# Tom Rokicki's rule tree generation code:
class GenerateRuleTree:

    def __init__(self,numStates,numNeighbors,f):
    
        self.numParams = numNeighbors + 1 ;
        self.world = {}
        self.r = []
        self.params = {}
        self.nodeSeq = 0
        self.numStates = numStates
        self.numNeighbors = numNeighbors
        self.f = f
        
        self.recur(self.numParams)

    def getNode(self,n):
        if n in self.world:
            return self.world[n]
        else:
            new_node = self.nodeSeq
            self.nodeSeq += 1
            self.r.append(n)
            self.world[n] = new_node
            return new_node

    def recur(self,at):
        if at == 0:
            return self.f(self.params)
        n = str(at)
        for i in range(self.numStates):
            if at==self.numParams:
                golly.show('Generating rule tree: '+str(100*i/self.numStates)+'%...')
                golly.update()
            self.params[self.numParams-at] = i
            n += " " + str(self.recur(at-1))
        return self.getNode(n)
      
    def writeRuleTree(self,name):
        # we write to a rule tree file in user's rules directory
        f=open(golly.getdir('rules')+name+'.tree', 'w')
        f.write('# written by AbsoluteTurmite-gen.py\n')
        f.write("num_states=" + str(self.numStates)+"\n")
        f.write("num_neighbors=" + str(self.numNeighbors)+"\n")
        f.write("num_nodes=" + str(len(self.r))+"\n")
        for rule in self.r:
            f.write(rule+"\n")
        f.close()

# generate the rule tree from the transition function
n_neighbors = 4
gen = GenerateRuleTree(total_states,n_neighbors,f)
gen.writeRuleTree(prefix+'-'+spec_string)

# we also export a colors file (just Golly's default random colors)
f = open(golly.getdir('rules')+prefix+'.colors','w')
f.write('# written by AbsoluteTurmite-gen.py\ncolor = 0 48 48 48\n')
f.write('color = 1 0 255 127\ncolor = 2 127 0 255\ncolor = 3 148 148 148\ncolor = 4 128 255 0\ncolor = 5 255 0 128\ncolor = 6 0 128 255\ncolor = 7 1 159 0\ncolor = 8 159 0 1\ncolor = 9 255 254 96\ncolor = 10 0 1 159\ncolor = 11 96 255 254\ncolor = 12 254 96 255\ncolor = 13 126 125 21\ncolor = 14 21 126 125\ncolor = 15 125 21 126\ncolor = 16 255 116 116\ncolor = 17 116 255 116\ncolor = 18 116 116 255\ncolor = 19 228 227 0\ncolor = 20 28 255 27\ncolor = 21 255 27 28\ncolor = 22 0 228 227\ncolor = 23 227 0 228\ncolor = 24 27 28 255\ncolor = 25 59 59 59\ncolor = 26 234 195 176\ncolor = 27 175 196 255\ncolor = 28 171 194 68\ncolor = 29 194 68 171\ncolor = 30 68 171 194\ncolor = 31 72 184 71\ncolor = 32 184 71 72\ncolor = 33 71 72 184\ncolor = 34 169 255 188\ncolor = 35 252 179 63\ncolor = 36 63 252 179\ncolor = 37 179 63 252\ncolor = 38 80 9 0\ncolor = 39 0 80 9\ncolor = 40 9 0 80\ncolor = 41 255 175 250\ncolor = 42 199 134 213\ncolor = 43 115 100 95\ncolor = 44 188 163 0\ncolor = 45 0 188 163\ncolor = 46 163 0 188\ncolor = 47 203 73 0\ncolor = 48 0 203 73\ncolor = 49 73 0 203\ncolor = 50 94 189 0\ncolor = 51 189 0 94')
f.close()

# now we can switch to the new rule
# problem: sometimes the file is still writing when we try to read it
golly.setrule(prefix+'-'+spec_string)
golly.new(prefix+'-demo.rle')
golly.setcell(0,0,n_colors) # start with a turmite facing N
golly.show('Created '+prefix+'-'+spec_string+'.tree, and selected this rule.')
