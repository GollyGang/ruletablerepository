import java.io.RandomAccessFile;
import java.util.*;

public class BLoop{
	
	/* Put your state count, neighbor count, and function here */
	final static int numStates = 7;
	final static int numNeighbors = 8;
	
	/*                              0   1   2   3  4  5  6  7  8 */
	/* order for nine neighbors is nw, ne, sw, se, n, w, e, s, c */
	/* order for five neighbors is n, w, e, s, c */
	int f(int[] a){
		/*
		 * 0-off
		 * 1-wire
		 * 2-extend header (ext)
		 * 3-turn header
		 * 4-tail
		 * 5-point of construction (poc)
		 * 6-transition state (ts)
		 */
		//count the surrounding cells
		int wire = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 1){
				wire++;
			}
		}
		int ext = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 2){
				ext++;
			}
		}
		int turn = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 3){
				turn++;
			}
		}
		int tail = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 4){
				tail++;
			}
		}
		int poc = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 5){
				poc++;
			}
		}
		int ts = 0;
		for(int i = 0; i < 8; i++){
			if(a[i] == 6){
				ts++;
			}
		}
		//turn removes extra wire that prevents it from turning the loop too soon
		if(a[8] == 3 && wire == 1 && ext == 0 && turn == 1 && tail == 1 && poc == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4 && a[1] == 4){
						return 0;
					}
					if(i == 5 && a[0] == 4){
						return 0;
					}
					if(i == 6 && a[3] == 4){
						return 0;
					}
					if(i == 7 && a[2] == 4){
						return 0;
					}
				}
			}
		}
		if(a[8] == 3 && wire == 0 && ext == 0 && turn == 1 && tail == 1 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4 && a[1] == 4 && a[0] == 5){
						return 0;
					}
					if(i == 5 && a[0] == 4 && a[2] == 5){
						return 0;
					}
					if(i == 6 && a[3] == 4 && a[1] == 5){
						return 0;
					}
					if(i == 7 && a[2] == 4 && a[3] == 5){
						return 0;
					}
				}
			}
		}
		//turn retracts wire
		if(a[8] == 3 && wire == 1 && ext == 0 && turn == 0 && tail == 1 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[1] == 4){
						return 0;
					}
					if(i == 5 && a[0] == 4){
						return 0;
					}
					if(i == 6 && a[3] == 4){
						return 0;
					}
					if(i == 7 && a[2] == 4){
						return 0;
					}
				}
			}
		}
		if(a[8] == 3 && wire == 1 && ext == 0 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 3 && wire == 0 && ext == 0 && turn == 0 && tail == 1 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 3 && wire == 0 && ext == 0 && turn == 1 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 3 && wire == 0 && ext == 0 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 3 && wire == 0 && ext == 0 && turn == 1 && tail == 1 && poc == 0 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4 && a[0] == 4){
						return 0;
					}
					if(i == 5 && a[2] == 4){
						return 0;
					}
					if(i == 6 && a[1] == 4){
						return 0;
					}
					if(i == 7 && a[3] == 4){
						return 0;
					}
				}
			}
		}
		//turns creats new poc
		if(a[8] == 3 && wire == 0 && tail == 1 && ext == 0 && turn == 1 && ts == 0 && poc == 1){
			for(int i = 0; i < 4; i++){
				if(a[i] == 5){
					if(i == 0){
						return 5;
					}
					if(i == 1){
						return 5;
					}
					if(i == 2){
						return 5;
					}
					if(i == 3){
						return 5;
					}
				}
			}
		}
		//ext retracts wire
		if(a[8] == 2 && wire == 1 && ext == 0 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 2 && wire == 0 && ext == 0 && turn == 0 && tail == 1 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 2 && wire == 0 && ext == 1 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 2 && wire == 0 && ext == 0 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 2 && wire == 0 && ext == 1 && turn == 0 && tail == 1 && poc == 0 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 2){
					if(i == 4 && a[0] == 4){
						return 0;
					}
					if(i == 5 && a[2] == 4){
						return 0;
					}
					if(i == 6 && a[1] == 4){
						return 0;
					}
					if(i == 7 && a[3] == 4){
						return 0;
					}
				}
			}
		}
		//ext becomes new poc for new loop
		if(wire == 1 && tail == 1 && ts == 1 && poc == 0 && a[8] == 2){
			return 5;
		}
		//headers become tails
		if(a[8] == 2 || a[8] == 3){
			return 4;
		}
		//tails become turns to retract from new loop
		if(a[8] == 4 && wire == 1 && ext == 1 && turn == 0 && tail == 0 && poc == 0 && ts == 1){
			return 3;
		}
		//tails become wire
		if(a[8] == 4){
			return 1;
		}
		//wire gets deleted to remove diagonal wire end from loop
		if(a[8] == 1 && wire == 1 && ext == 0 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			for(int i = 0; i < 4; i++){
				if(a[i] == 1){
					if(i == 0){
						return 0;
					}
					if(i == 1){
						return 0;
					}
					if(i == 2){
						return 0;
					}
					if(i == 3){
						return 0;
					}
				}
			}
		}
		//extra wire bump gets removed by turn signal
		if(a[8] == 1 && wire == 0 && ext == 0 && turn == 2 && tail == 0 && poc == 0 && ts == 0){
			return 0;
		}
		//wire becomes turn signal only if there is 1 or 2
		if((turn == 2 || turn == 1) && a[8] == 1){
			return 3;
		}
		//wire becomes ext
		if(ext > 0 && a[8] == 1){
			return 2;
		}
		//wire stays wire
		if(a[8] == 1){
			return 1;
		}
		//ext makes new poc to start the wire
		if(a[8] == 0 && wire == 0 && ext == 1 && turn == 0 && tail == 0 && poc == 1){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[0] == 2){
						return 5;
					}
					if(i == 5 && a[2] == 2){
						return 5;
					}
					if(i == 6 && a[1] == 2){
						return 5;
					}
					if(i == 7 && a[3] == 2){
						return 5;
					}
				}
			}
		}
		//turn makes new poc to start the wire
		if(a[8] == 0 && wire == 0 && ext == 0 && turn == 1 && tail == 0 && poc == 1){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[0] == 3){
						return 5;
					}
					if(i == 5 && a[2] == 3){
						return 5;
					}
					if(i == 6 && a[1] == 3){
						return 5;
					}
					if(i == 7 && a[3] == 3){
						return 5;
					}
				}
			}
		}
		if(a[8] == 0 && wire == 2 && ext == 0 && turn == 2 && tail == 0 && poc == 0 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4 && a[1] == 3){
						return 5;
					}
					if(i == 5 && a[0] == 3){
						return 5;
					}
					if(i == 6 && a[3] == 3){
						return 5;
					}
					if(i == 7 && a[2] == 3){
						return 5;
					}
				}
			}
		}
		//poc becomes wire to start construction
		if(a[8] == 5 && wire == 0 && ext == 1 && turn == 0 && poc == 0 && tail == 1){
			for(int i = 4; i < 8; i++){
				if(a[i] == 2){
					if(i == 4 && a[6] == 4){
						return 1;
					}
					if(i == 5 && a[4] == 4){
						return 1;
					}
					if(i == 6 && a[7] == 4){
						return 1;
					}
					if(i == 7 && a[5] == 4){
						return 1;
					}
				}
			}
		}
		//poc becomes wire to start construction
		if(a[8] == 5 && wire == 0 && ext == 0 && turn == 1 && poc == 0 && tail == 1){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4 && a[6] == 4){
						return 1;
					}
					if(i == 5 && a[4] == 4){
						return 1;
					}
					if(i == 6 && a[7] == 4){
						return 1;
					}
					if(i == 7 && a[5] == 4){
						return 1;
					}
				}
			}
		}
		//poc becomes wire to turn wire
		if(a[8] == 5 && wire == 0 && ext == 0 && turn == 1 && poc == 0 && tail == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4){
						return 1;
					}
					if(i == 5){
						return 1;
					}
					if(i == 6){
						return 1;
					}
					if(i == 7){
						return 1;
					}
				}
			}
		}
		//poc becomes ts to exted wire
		if(a[8] == 5 && wire == 0 && ext > 0 && turn == 0 && poc == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 2){
					if(i == 4 && (a[0] == 2 || a[0] == 0 || a[0] == 4)){
						return 6;
					}
					if(i == 5 && (a[2] == 2 || a[2] == 0 || a[2] == 4)){
						return 6;
					}
					if(i == 6 && (a[1] == 2 || a[1] == 0 || a[1] == 4)){
						return 6;
					}
					if(i == 7 && (a[3] == 2 || a[3] == 0 || a[3] == 4)){
						return 6;
					}
				}
			}
		}
		if(a[8] == 5 && wire == 1 && ext == 2 && turn == 0 && tail == 1 && poc == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 2){
					if(i == 4 && (a[0] == 2 || a[0] == 0 || a[0] == 4)){
						return 6;
					}
					if(i == 5 && (a[2] == 2 || a[2] == 0 || a[2] == 4)){
						return 6;
					}
					if(i == 6 && (a[1] == 2 || a[1] == 0 || a[1] == 4)){
						return 6;
					}
					if(i == 7 && (a[3] == 2 || a[3] == 0 || a[3] == 4)){
						return 6;
					}
				}
			}
		}
		if(a[8] == 5 && wire == 1 && ext == 1 && turn == 0 && tail == 0 && poc == 0 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 1){
					if(i == 4 && a[0] == 2){
						return 6;
					}
					if(i == 5 && a[2] == 2){
						return 6;
					}
					if(i == 6 && a[1] == 2){
						return 6;
					}
					if(i == 7 && a[3] == 2){
						return 6;
					}
				}
			}
		}
		//poc gets deleted to be moved by turn signal
		if(a[8] == 5 && (turn == 2 || turn == 3) && wire == 0 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 5 && turn == 1 && wire == 0 && tail == 2 && poc == 0 && ts == 0){
			return 0;
		}
		if(a[8] == 5 && turn == 1 && wire == 1 && tail == 1 && poc == 0 && ts == 0){
			return 0;
		}
		//poc gets deleted if its by a ts
		if(a[8] == 5 && ts == 1){
			return 0;
		}
		//poc stays poc
		if(a[8] == 5 && poc == 0){
			return 5;
		}
		//poc makes wire to stop turn from entering first time
		if(a[8] == 0 && wire == 0 && ext == 0 && turn == 0 && tail == 1 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[1] == 4){
						return 1;
					}
					if(i == 5 && a[0] == 4){
						return 1;
					}
					if(i == 6 && a[3] == 4){
						return 1;
					}
					if(i == 7 && a[2] == 4){
						return 1;
					}
				}
			}
		}
		//ext makes poc at a really sharp turn
		if(a[8] == 0 && turn == 0 && tail == 1 && wire == 1 && ext == 1 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[0] == 1 && a[5] == 2 && a[2] == 4){
						return 5;
					}
					if(i == 5 && a[2] == 1 && a[7] == 2 && a[3] == 4){
						return 5;
					}
					if(i == 6 && a[1] == 1 && a[4] == 2 && a[0] == 4){
						return 5;
					}
					if(i == 7 && a[3] == 1 && a[6] == 2 && a[1] == 4){
						return 5;
					}
				}
			}
		}
		//turn make new poc to move it to a different corner
		if(a[8] == 0 && turn == 2 && wire == 1 && ext == 0 && poc == 1 && ts == 0){
			return 5;
		}
		if(a[8] == 0 && turn == 1 && wire == 1 && ext == 0 && tail == 1 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 3){
					if(i == 4){
						return 5;
					}
					if(i == 5){
						return 5;
					}
					if(i == 6){
						return 5;
					}
					if(i == 7){
						return 5;
					}
				}
			}
		}
		//ext make poc at start of construction
		if(a[8] == 0 && turn == 0 && wire == 0 && ext == 2 && tail == 0 && poc == 1 && ts == 0){
			for(int i = 4; i < 8; i++){
				if(a[i] == 5){
					if(i == 4 && a[6] == 2){
						return 5;
					}
					if(i == 5 && a[4] == 2){
						return 5;
					}
					if(i == 6 && a[7] == 2){
						return 5;
					}
					if(i == 7 && a[5] == 2){
						return 5;
					}
				}
			}
		}
		//ts makes poc to extend wire
		if(a[8] == 0 && poc == 1 && ts == 1){
			for(int i = 4; i < 8; i++){
				if(a[i] == 6){
					if(i == 4){
						return 5;
					}
					if(i == 5){
						return 5;
					}
					if(i == 6){
						return 5;
					}
					if(i == 7){
						return 5;
					}
				}
			}
		}
		//ts becomes tail when finishing new loop
		if(a[8] == 6 && (ext == 1 || turn == 1) && poc == 0){
			return 4;
		}
		//ts becomes wire to extend
		if(a[8] == 6 && poc == 1){
			return 1;
		}
		//ts gets deleted
		if(a[8] == 6){
			return 0;
		}
		//nothing stays nothing
		if(a[8] == 0){
			return 0;
		}
		//all other exeptions become ts which gets deleted
		return 6;
	}
	
	final static int numParams = numNeighbors + 1;
	HashMap<String, Integer> world = new HashMap<String, Integer>();
	ArrayList<String> r = new ArrayList<String>();
	int[] params = new int[numParams];
	int nodeSeq = 0;
	
	int getNode(String n){
		Integer found = world.get(n);
		if(found == null){
			found = nodeSeq++;
			r.add(n);
			world.put(n, found);
		}
		return found;
	}
	
	int recur(int at){
		if(at == 0)
			return f(params);
		String n = "" + at;
		for(int i = 0; i < numStates; i++){
			params[numParams - at] = i;
			n += " " + recur(at - 1);
		}
		return getNode(n);
	}
	
	void writeRuleTree(){
		try{
			RandomAccessFile file = new RandomAccessFile("C:\\" + this.getClass().getName() + ".tree", "rw");
			System.out.println("num_states=" + numStates);
			file.writeBytes("num_states=" + numStates + "\n");
			System.out.println("num_neighbors=" + numNeighbors);
			file.writeBytes("num_neighbors=" + numNeighbors + "\n");
			System.out.println("num_nodes=" + r.size());
			file.writeBytes("num_nodes=" + r.size() + "\n");
			for(int i = 0; i < r.size(); i++){
				System.out.println(r.get(i));
				file.writeBytes(r.get(i) + "\n");
			}
		}catch(Exception e){
		}
	}
	
	public static void main(String[] args) throws Exception{
		BLoop rtg = new BLoop();
		rtg.recur(numParams);
		rtg.writeRuleTree();
	}
}