An implementation of Historical Life, showing where cells were once alive.

Implemented as a .table file by Adam P. Goucher.

Instructions for use:

1. Place the .table and .colors file in your Golly/Rules folder.
2. Type 'HistoricalLife' into the rule entry field under Control | Set Rule...