# Removes all spaces from the current clipboard's hex pattern
# so we can easily paste in Paul Callahan's patterns from
# http://www.radicaleye.com/lifepage/hexrule.txt.
# Author: Andrew Trevorrow (andrew@trevorrow.com), Oct 2009.

# For example, here is a p4 glider in Hex-B2oS2m34:
'''
       . . O .
      . . . O
     O . . O
    . . . O
   . . . O
'''

import golly as g
g.setclipstr(g.getclipstr().replace(' ',''))
g.show("Clipboard's hex pattern has been converted and is ready to paste.")
