Thank you for downloading Blocks and Walls by

W. Conrad Walden

For information on the rule, look at the rule file.

The rule table is in the public domain. The icons (thanks Ssaamm!)
are in the public domain as well. You have complete right use them
to your privilege.

The pattern Block Mover is created and distributed by W. Conrad Walden.
It is in public domain.

All other patterns have been written by various generous people
at the forums and Conwaylife.com. They are also in the public domain.
Thanks, guys!

~ W. Conrad Walden
