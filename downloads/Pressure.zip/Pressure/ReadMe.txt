"Pressure" is a rule that's loosely based on gas particles exerting pressure on the walls of a chamber.  It's not intended to be an accurate simulation of real gases.

We start with an enclosed region whose walls are formed from cells in the 'brick' state (state 7).  Inside the chamber are some particles, which are 1-cell spaceships moving at speed c.  There are 4 types of these, one for each of the cardinal directions (states 1-4).  States 5 and 6 represent 2 overlapping particles in opposite directions.  The rules prevent other sorts of overlap, and guarantee that the number of particles never changes.  (This is similar to the Lattice Gas rule, HPP, but using fewer states.)  When a particle touches a brick, it pushes it and gets reflected; when necessary, new bricks appear next to the pushed one in order to prevent gaps from forming in the walls.

There are many possible rules like that, and after much experimentation to see how they behave I settled on the one in "Pressure.table".  Initially I was expecting that the chamber would expand in a roughly circular form, but that doesn't happen for long in any of the rules that I tried.  If there's only one particle, it eventually starts moving back and forth in either a single horizontal or vertical line or a pair of adjacent lines, as in the pattern given in the file "back+forth.rle":

#C Four examples of a single particle moving back and forth.
#C The top two are minimal-width examples of 1-line and 2-line
#C motion; the others are wider.
x = 6, y = 47, rule = Pressure
2.G$.GBG$2.G5$.2G$G.CG$G2.G$.2G4$2.G$.G.G$.G.G$.G.G$.GBG$.G.G$.G.G$.G
.G$.G.G$.G.G$.G.G$.G.G$.G.G$.G.G$2.G3$2.2G$.G2.G$.G2.G$.G2.G$G3.CG$G
4.G$.G2.G$.G2.G$.G2.G$.G2.G$.G2.G$.G2.G$.G2.G$.G2.G$.G2.G$2.2G!

I don't know for sure that all 1-particle patterns end up that way, but I haven't found any that don't.  It can take a while, as in "1particle.rle":

#C One particle bounces around for 1572 gens before settling into
#C a 1-line back and forth motion.
x = 23, y = 17, rule = Pressure
6.12G$5.G12.G$4.G14.G$3.G16.G$2.G18.G$.G20.G$G21.G$G21.G$G21.G$.G20.G
$2.G19.G$3.G18.G$4.G16.G$5.G14.G$6.G3.B8.G$7.G10.G$8.10G!

With more than one particle, things get more interesting.  Usually the chamber expands sort of randomly for a while.  As it grows, the particle density decreases and collisions become rarer.  As a result, individual particles have a chance to start moving as they do in 1-particle systems, and narrow, straight protrusions form.  At first these don't go very far before collisions make them stop.  After a while, the chamber gets partitioned into separate regions, with moving, mostly straight walls.  The walls often push through and clean up debris that was produced earlier.  The file "7particles.rle" shows a fairly typical example:

# Typical 7-particle system.  I don't know its final fate.
x = 5, y = 5, rule = Pressure
.G$GA2G$G3AG$G3AG$.3G!

As long as some particles are moving horizontally and some are moving vertically, their paths will eventually cross.  Unless the timing is perfect (as in some symmetric patterns), they'll interact, either by colliding, or by one particle pushing a wall into the path of the other.  This will change the way they move.  After enough interactions like that, it's likely that all particles will eventually be moving along parallel lines, and the pattern may expand in one direction forever.  This tends to happen fairly quickly if the number of particles is small, as in "5particles.rle":

#C 5-particle system expands horizontally forever starting in
#C gen 82554.
x = 5, y = 5, rule = Pressure
.3G$G.CBG$GBC.G$G2.CG$.3G!

But even if all particles are moving in parallel, they may eventually interact.  The file "horizontal-vertical.rle" has an artificial demonstration of that:

#C 2-particle pattern expands horizontally for 478138 gens, and
#C then grows vertically forever.
x = 34, y = 16, rule = Pressure
2.30G$.G30.G$.G30.G$G16.B15.G$.G30.G$.G30.G$.G11.9G10.G$.G10.G9.G9.G$
.G10.G9.G9.G$.G9.G5.B5.G8.G$.G10.G9.G9.G$.G10.G9.G9.G$2.11G9.10G$12.G
9.G$12.G9.G$13.9G!

A more natural example is shown in "3particles.rle":

#C 3-particle pattern expands vertically from gen 3160 to 26257,
#C horizontally from gen 100,058 to 7,492,990, vertically from
#C 52,683,963 to 387,506,073, and vertically forever starting at
#C gen 996,501,790.
x = 4, y = 4, rule = Pressure
.G$GBG$GCAG$.2G!

In addition to straight lines, patterns occasionally form hyperbolic arcs, but (as far as I know) they can't grow forever.  An example is in the file "hyperbolic.rle":

#C 5-particle system produces two hyperbolic arcs between gens
#C 1,197,000 and 1,273,000, one between gens 1.4725*10^9 and
#C 2.0057*10^9, and another between gens 3.2231*10^9 and 4.1219*10^9.
x = 6, y = 6, rule = Pressure
.4G$G.C.BG$G.A2.G$G.CA.G$G4.G$.4G!


It's possible for any number of particles to move back and forth along a single line, with walls between them.  For example, in the pattern "3particles-in-line.rle" there are 3 particles:

#C 3 particles move between 4 walls.  In generation t, the distance
#C between the inner walls is about  sqrt((5-sqrt(17))/2) * sqrt(t)
#C ~ 0.662 sqrt(t);  the distance between each outer wall and the
#C nearest inner wall is about  sqrt((7-sqrt(17))/4) * sqrt(t)
#C ~ 0.848 sqrt(t).
x = 13, y = 7, rule = Pressure
.11G$G3.G3.G3.G$G3.G3.G3.G$G.B.G.B.G.B.G$G3.G3.G3.G$G3.G3.G3.G$.11G!

For n particles, let the distances between walls, from left to right, be x[1]*sqrt(t),  ...,  x[n]*sqrt(t).  Let  x[0] = x[n+1] = infinity.  Then, for each i from 1 to n, we have:

           2         1          1
x[i]  =  ----  -  ------  -  ------
         x[i]     x[i-1]     x[i+1]

Solving this system of equations gives the x[i]'s as roots of polynomials, but I haven't figured out the degrees of the polynomials or any asymptotic formulas for the roots.

The file "many-in-line.rle" shows such systems with up to 12 particles.  Note that we don't need to fully enclose them within walls.

#C Up to 12 particles move horizontally between walls.
x = 49, y = 117, rule = Pressure
23.3G$22.G3.G$22.G3.G$22.G.B.G$22.G3.G$22.G3.G$23.3G4$21.3G.3G$20.G3.
G3.G$20.G3.G3.G$20.G.B.G.B.G$20.G3.G3.G$20.G3.G3.G$21.3G.3G4$19.3G5.
3G$18.G3.G3.G3.G$18.G3.G3.G3.G$18.G.B.G.B.G.B.G$18.G3.G3.G3.G$18.G3.G
3.G3.G$19.3G5.3G4$17.3G.3G5.3G$16.G3.G3.G3.G3.G$16.G3.G3.G3.G3.G$16.G
.B.G.B.G.B.G.B.G$16.G3.G3.G3.G3.G$16.G3.G3.G3.G3.G$17.3G.3G5.3G4$15.
3G5.3G5.3G$14.G3.G3.G3.G3.G3.G$14.G3.G3.G3.G3.G3.G$14.G.B.G.B.G.B.G.B
.G.B.G$14.G3.G3.G3.G3.G3.G$14.G3.G3.G3.G3.G3.G$15.3G5.3G5.3G4$13.3G.
3G5.3G5.3G$12.G3.G3.G3.G3.G3.G3.G$12.G3.G3.G3.G3.G3.G3.G$12.G.B.G.B.G
.B.G.B.G.B.G.B.G$12.G3.G3.G3.G3.G3.G3.G$12.G3.G3.G3.G3.G3.G3.G$13.3G.
3G5.3G5.3G4$11.3G5.3G5.3G5.3G$10.G3.G3.G3.G3.G3.G3.G3.G$10.G3.G3.G3.G
3.G3.G3.G3.G$10.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G$10.G3.G3.G3.G3.G3.G3.G
3.G$10.G3.G3.G3.G3.G3.G3.G3.G$11.3G5.3G5.3G5.3G4$9.3G.3G5.3G5.3G5.3G$
8.G3.G3.G3.G3.G3.G3.G3.G3.G$8.G3.G3.G3.G3.G3.G3.G3.G3.G$8.G.B.G.B.G.B
.G.B.G.B.G.B.G.B.G.B.G$8.G3.G3.G3.G3.G3.G3.G3.G3.G$8.G3.G3.G3.G3.G3.G
3.G3.G3.G$9.3G.3G5.3G5.3G5.3G4$7.3G5.3G5.3G5.3G5.3G$6.G3.G3.G3.G3.G3.
G3.G3.G3.G3.G$6.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$6.G.B.G.B.G.B.G.B.G.B.G.
B.G.B.G.B.G.B.G$6.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$6.G3.G3.G3.G3.G3.G3.G
3.G3.G3.G$7.3G5.3G5.3G5.3G5.3G4$5.3G.3G5.3G5.3G5.3G5.3G$4.G3.G3.G3.G
3.G3.G3.G3.G3.G3.G3.G$4.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$4.G.B.G.B.G.B
.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G$4.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$4.G
3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$5.3G.3G5.3G5.3G5.3G5.3G4$3.3G5.3G5.3G
5.3G5.3G5.3G$2.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$2.G3.G3.G3.G3.G3.G
3.G3.G3.G3.G3.G3.G$2.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G$2.
G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$2.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G
3.G$3.3G5.3G5.3G5.3G5.3G5.3G4$.3G.3G5.3G5.3G5.3G5.3G5.3G$G3.G3.G3.G3.
G3.G3.G3.G3.G3.G3.G3.G3.G$G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$G.B.G
.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G.B.G$G3.G3.G3.G3.G3.G3.G3.G3.
G3.G3.G3.G3.G$G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G3.G$.3G.3G5.3G5.3G5.
3G5.3G5.3G!


Symmetric patterns can do things that I haven't seen in asymmetric ones.  Here are 4 examples:

"bilateral-symm.rle":

#C 4-particle pattern grows horizontally, with jagged top and bottom
#C edges, for about 57000 gens, then gets more complicated.  Starting
#C about gen 1.02*10^9, it grows horizontally forever.
x = 7, y = 3, rule = Pressure
.5G$G2BD2BG$.5G!

"rotational-symm-1.rle":

#C 4-particle pattern with 90 degree rotational symmetry.  At about
#C gen 86,000,000, it starts growing predictably, alternately pushing
#C the boundaries out along the axes and moving some internal
#C boundaries.
x = 9, y = 9, rule = Pressure
6.G$.G3.GAG$GDG3.G$.G2$7.G$2.G3.GBG$.GCG3.G$2.G!

"rotational-symm-2.rle":

#C 4-particle pattern with 90 degree rotational symmetry.  Some
#C time around gen 10^8, it becomes predictable, repeatedly going
#C through a complicated series of steps, each taking 25 times as
#C long as the preceding one.  For  n >= 0,  the outer boundary is
#C almost a perfect square, with a 1-cell bump on each side, in gen
#C 452474512/3 * 25^n - 805030 * 5^n + 1882 * n + 20145521/3;
#C the bounding box then is a square of side  14440 * 5^n - 21.
x = 7, y = 7, rule = Pressure
.G3.G$GAG.GBG$.G3.G2$.G3.G$GDG.GCG$.G3.G!

"slow-counter.rle":

#C 4-particle pattern grows along the x- and y-axes, with binary
#C counters near the center in all 4 quadrants.  On average, each
#C increment takes 2 gens longer than the preceding one.
x = 7, y = 11, rule = Pressure
3.G$2.GAG$3.G2$.G3.G$GBG.GDG$.G3.G2$3.G$2.GCG$3.G!


Oscillators are rare; two are shown in "oscs.rle":

#C Two oscillators, with periods 2 and 4.
x = 16, y = 8, rule = Pressure
GDG8.2G$C.A7.G2.G$GBG6.G.D2.G$8.G.A4.G$8.G4.C.G$9.G2.B.G$10.G2.G$11.
2G!

The smaller one reflects any particles that collide with it, but it can be destroyed by bricks being pushed into it, as shown in "osc-reflects.rle":

#C Oscillator reflects particles, then gets destroyed by bricks.
x = 24, y = 5, rule = Pressure
8.B13.G$6.B4.GDG7.GDG$4.B6.C.A8.G$2.B8.GBG$B!

If used carefully, it can serve as a fixed reflector, as in "fast-counter.rle", a variant of the binary counter mentioned above:

#C Four binary counters.  On average, each increment takes 8 gens.
x = 21, y = 25, rule = Pressure
9.GDG$9.C.A$9.GBG5$10.G$9.GAG$10.G2$GDG5.G3.G5.GDG$C.A4.GBG.GDG4.C.A$
GBG5.G3.G5.GBG2$10.G$9.GCG$10.G5$9.GDG$9.C.A$9.GBG!

Maybe such oscillators could be used to construct logic gates; I haven't investigated that.

Dean Hickerson, 4/13/2010
